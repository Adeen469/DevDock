export const mockCases = [
  {
    id: 1,
    title: 'Wage Theft — ABC Garments Ltd.',
    caseNo: 'CNR-MH-2024-001823',
    court: 'Labour Court, Pune',
    status: 'active',
    nextHearing: '2025-04-18',
    lastUpdate: '2025-03-28',
    riskScore: 32,
    type: 'Labour',
    description: 'Employer withheld wages for 3 months without justification.',
    sections: ['Payment of Wages Act, 1936 — Sec 15', 'BNS Sec 316'],
  },
  {
    id: 2,
    title: 'Landlord Dispute — Property Damage',
    caseNo: 'CNR-KA-2023-009441',
    court: 'Civil Court, Bengaluru',
    status: 'pending',
    nextHearing: '2025-05-02',
    lastUpdate: '2025-03-15',
    riskScore: 58,
    type: 'Civil',
    description: 'Landlord refusing to return security deposit and claiming damages.',
    sections: ['Transfer of Property Act — Sec 108', 'CPC Order 37'],
  },
  {
    id: 3,
    title: 'Cheque Bounce — Business Partner',
    caseNo: 'CNR-DL-2024-003311',
    court: 'Metropolitan Magistrate, Delhi',
    status: 'closed',
    nextHearing: null,
    lastUpdate: '2025-02-10',
    riskScore: 10,
    type: 'Criminal',
    description: 'Business partner issued dishonoured cheque worth ₹4.5L.',
    sections: ['Negotiable Instruments Act — Sec 138'],
  },
];

export const mockHearings = [
  { id: 1, caseTitle: 'Wage Theft — ABC Garments Ltd.', date: '2025-04-18', time: '11:00 AM', court: 'Labour Court, Pune', judge: 'Hon. R.K. Sharma', status: 'upcoming' },
  { id: 2, caseTitle: 'Landlord Dispute', date: '2025-05-02', time: '02:30 PM', court: 'Civil Court, Bengaluru', judge: 'Hon. P.V. Rao', status: 'upcoming' },
  { id: 3, caseTitle: 'Property Inheritance', date: '2025-04-05', time: '10:00 AM', court: 'Family Court, Mumbai', judge: 'Hon. S.N. Iyer', status: 'completed' },
  { id: 4, caseTitle: 'Cheque Bounce — Partner', date: '2025-03-12', time: '03:00 PM', court: 'MM Court, Delhi', judge: 'Hon. A.K. Gupta', status: 'completed' },
];

export const mockLaws = [
  {
    id: 1,
    code: 'BNS § 316',
    title: 'Cheating by Personation',
    category: 'Criminal',
    description: 'Whoever cheats by personation shall be punished with imprisonment of either description for a term which may extend to three years.',
    punishment: 'Up to 3 years imprisonment and/or fine',
    replaces: 'IPC § 416',
    tags: ['fraud', 'cheating', 'identity'],
  },
  {
    id: 2,
    code: 'BNS § 115',
    title: 'Voluntary Causing Hurt',
    category: 'Criminal',
    description: 'Whoever voluntarily causes hurt to any person is said to "voluntarily cause hurt."',
    punishment: '1 year imprisonment and/or ₹10,000 fine',
    replaces: 'IPC § 323',
    tags: ['assault', 'physical harm', 'hurt'],
  },
  {
    id: 3,
    code: 'Article 21',
    title: 'Protection of Life and Personal Liberty',
    category: 'Constitutional',
    description: 'No person shall be deprived of his life or personal liberty except according to procedure established by law.',
    punishment: 'N/A — Fundamental Right',
    replaces: null,
    tags: ['fundamental rights', 'liberty', 'constitutional'],
  },
  {
    id: 4,
    code: 'POCSO § 4',
    title: 'Punishment for Penetrative Sexual Assault',
    category: 'Special Law',
    description: 'Whoever commits penetrative sexual assault shall be punished with rigorous imprisonment of not less than ten years.',
    punishment: 'Minimum 10 years to life imprisonment',
    replaces: null,
    tags: ['child protection', 'sexual assault', 'POCSO'],
  },
];

export const mockDocuments = [
  { id: 1, name: 'FIR_Copy_2024.pdf', type: 'pdf', size: '234 KB', uploaded: '2025-03-01', case: 'Wage Theft' },
  { id: 2, name: 'Wage_Slips_Jan_Mar.pdf', type: 'pdf', size: '1.2 MB', uploaded: '2025-03-05', case: 'Wage Theft' },
  { id: 3, name: 'Rent_Agreement_2023.pdf', type: 'pdf', size: '456 KB', uploaded: '2025-02-18', case: 'Landlord Dispute' },
  { id: 4, name: 'WhatsApp_Chat_Export.txt', type: 'txt', size: '88 KB', uploaded: '2025-02-20', case: 'Landlord Dispute' },
  { id: 5, name: 'Cheque_Image_1.jpg', type: 'img', size: '320 KB', uploaded: '2025-01-15', case: 'Cheque Bounce' },
];

export const mockMemories = [
  { id: 1, title: 'Rights during police questioning', content: 'Under Article 20(3) you cannot be compelled to be a witness against yourself. You have the right to remain silent.', tags: ['police', 'rights', 'arrest'], saved: '2025-03-10', pinned: true },
  { id: 2, title: 'Section 138 Cheque Bounce Timeline', content: 'Must send legal notice within 30 days of cheque return. Drawer has 15 days to pay. File complaint within 30 days after that.', tags: ['cheque', 'NI Act', 'timeline'], saved: '2025-02-28', pinned: false },
  { id: 3, title: 'Labour Court Procedure', content: 'File complaint with Inspector under Payment of Wages Act. Employer must appear within 30 days. Court can award compensation up to 10x unpaid wages.', tags: ['labour', 'wages', 'procedure'], saved: '2025-02-15', pinned: true },
];

export const mockChatMessages = [
  { id: 1, role: 'assistant', content: 'Aadab! I\'m your Insaaf AI Assistant. I can help you understand laws, analyze your situation, and guide you through legal processes in India. What can I help you with today?', time: '10:00 AM' },
  { id: 2, role: 'user', content: 'My employer has not paid my salary for 2 months. What can I do?', time: '10:01 AM' },
  { id: 3, role: 'assistant', content: 'This is a serious violation of your rights. Under the **Payment of Wages Act, 1936** (Section 3), wages must be paid before the 7th of the following month.\n\n**Your options:**\n1. **File a complaint** with the Labour Inspector in your area — this is free.\n2. **Send a legal notice** via a lawyer (costs ₹500–2000).\n3. **File with Labour Court** — if amount exceeds ₹50,000.\n\nYour employer can be fined up to **₹75,000** for delayed payment.\n\nWould you like me to explain the complaint filing process step by step?', time: '10:01 AM' },
  { id: 4, role: 'user', content: 'Yes please explain the process', time: '10:02 AM' },
];

export const mockAnalytics = {
  casesByType: [
    { name: 'Criminal', value: 12, color: '#ef4444' },
    { name: 'Civil', value: 18, color: '#3b82f6' },
    { name: 'Labour', value: 7, color: '#f59e0b' },
    { name: 'Family', value: 5, color: '#8b5cf6' },
    { name: 'Property', value: 9, color: '#22c55e' },
  ],
  monthlyRevenue: [
    { month: 'Oct', revenue: 85000, cases: 8 },
    { month: 'Nov', revenue: 92000, cases: 11 },
    { month: 'Dec', revenue: 78000, cases: 7 },
    { month: 'Jan', revenue: 105000, cases: 13 },
    { month: 'Feb', revenue: 118000, cases: 15 },
    { month: 'Mar', revenue: 134000, cases: 18 },
  ],
  caseOutcomes: [
    { name: 'Won', value: 28, color: '#22c55e' },
    { name: 'Lost', value: 8, color: '#ef4444' },
    { name: 'Settled', value: 14, color: '#f59e0b' },
    { name: 'Ongoing', value: 51, color: '#3b82f6' },
  ],
  hearingsByDay: [
    { day: 'Mon', count: 4 },
    { day: 'Tue', count: 6 },
    { day: 'Wed', count: 3 },
    { day: 'Thu', count: 7 },
    { day: 'Fri', count: 5 },
    { day: 'Sat', count: 2 },
  ],
};

export const mockLawyerCases = [
  { id: 1, clientName: 'Rajesh Mehta', title: 'Property Dispute vs. Builder', type: 'Civil', status: 'active', nextHearing: '2025-04-20', fee: '₹45,000', stage: 'Arguments', court: 'Civil Court, Pune' },
  { id: 2, clientName: 'Priya Sharma', title: 'Divorce & Custody', type: 'Family', status: 'active', nextHearing: '2025-04-22', fee: '₹60,000', stage: 'Evidence', court: 'Family Court, Pune' },
  { id: 3, clientName: 'TechCorp Pvt. Ltd.', title: 'Employment Termination', type: 'Labour', status: 'active', nextHearing: '2025-05-05', fee: '₹1,20,000', stage: 'Filing', court: 'Labour Court, Mumbai' },
  { id: 4, clientName: 'Amit Verma', title: 'Motor Accident Claim', type: 'Civil', status: 'pending', nextHearing: '2025-05-10', fee: '₹35,000', stage: 'Notice', court: 'MACT, Delhi' },
  { id: 5, clientName: 'Sonal Jain', title: 'Cheque Bounce Recovery', type: 'Criminal', status: 'active', nextHearing: '2025-04-25', fee: '₹25,000', stage: 'Summary Trial', court: 'MM Court, Bengaluru' },
];

export const mockMCQFlow = [
  {
    id: 1,
    question: 'Who is the primary person involved in the incident?',
    options: ['My employer / manager', 'A stranger', 'A family member', 'A government official'],
  },
  {
    id: 2,
    question: 'What type of harm occurred?',
    options: ['Physical assault / injury', 'Financial / monetary loss', 'Property damage', 'Harassment / mental distress'],
  },
  {
    id: 3,
    question: 'Where did the incident take place?',
    options: ['Workplace', 'Public place', 'My home / residence', 'Online / digital'],
  },
  {
    id: 4,
    question: 'Is there any documented evidence?',
    options: ['Yes — written documents', 'Yes — digital records / messages', 'Yes — witnesses', 'No evidence available'],
  },
];

export const mcqResult = {
  summary: 'Based on your answers, your employer may have committed offences under multiple Indian laws.',
  sections: [
    { code: 'Payment of Wages Act § 15', description: 'Non-payment of wages — you can file a complaint with Labour Inspector.', severity: 'high' },
    { code: 'BNS § 316', description: 'Cheating by misrepresentation — if employer made false promises.', severity: 'medium' },
    { code: 'BNS § 115', description: 'Voluntarily causing hurt — if physical intimidation was involved.', severity: 'low' },
  ],
  recommendation: 'We recommend filing a complaint with your area Labour Inspector first. This is free and can result in compensation up to 10x your unpaid wages.',
};

export const mockNotifications = [
  { id: 1, type: 'hearing', title: 'Hearing Tomorrow', message: 'Wage Theft case hearing at Labour Court, Pune at 11:00 AM', time: '2h ago', read: false },
  { id: 2, type: 'update', title: 'Case Update', message: 'Your lawyer filed a rejoinder in the Landlord Dispute case.', time: '1d ago', read: false },
  { id: 3, type: 'ai', title: 'AI Analysis Ready', message: 'Section recommendation for Cheque Bounce case is ready.', time: '2d ago', read: true },
];
