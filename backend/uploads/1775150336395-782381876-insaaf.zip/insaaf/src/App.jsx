import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import './styles/global.css';

// Public Pages
import RoleSelection from './pages/RoleSelection';
import Login from './pages/Login';
import Register from './pages/Register';
import NotFound from './pages/NotFound';

// Civilian Pages
import CivilianDashboard from './pages/civilian/Dashboard';
import LawSearch from './pages/civilian/LawSearch';
import Assistant from './pages/civilian/Assistant';
import CaseTracker from './pages/civilian/CaseTracker';
import MemoryBank from './pages/civilian/MemoryBank';
import Emergency from './pages/civilian/Emergency';
import ChatLawyer from './pages/civilian/ChatLawyer';

// Lawyer Pages
import LawyerDashboard from './pages/lawyer/LawyerDashboard';
import LawyerCases from './pages/lawyer/LawyerCases';
import LawyerHearings from './pages/lawyer/LawyerHearings';
import LawyerDocuments from './pages/lawyer/LawyerDocuments';
import AISummarizer from './pages/lawyer/AISummarizer';
import SectionRecommender from './pages/lawyer/SectionRecommender';
import DraftGenerator from './pages/lawyer/DraftGenerator';
import ClientChat from './pages/lawyer/ClientChat';
import Analytics from './pages/lawyer/Analytics';

function ProtectedRoute({ children, role }) {
  const { user, isAuth } = useAuth();
  if (!isAuth) return <Navigate to="/" replace />;
  if (role && user?.role !== role) {
    return <Navigate to={user?.role === 'lawyer' ? '/lawyer/dashboard' : '/dashboard'} replace />;
  }
  return children;
}

function AppRoutes() {
  const { user, isAuth } = useAuth();
  return (
    <Routes>
      {/* Public */}
      <Route path="/" element={
        isAuth
          ? <Navigate to={user?.role === 'lawyer' ? '/lawyer/dashboard' : '/dashboard'} replace />
          : <RoleSelection />
      } />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* Civilian */}
      <Route path="/dashboard" element={<ProtectedRoute role="civilian"><CivilianDashboard /></ProtectedRoute>} />
      <Route path="/law-search" element={<ProtectedRoute><LawSearch /></ProtectedRoute>} />
      <Route path="/assistant" element={<ProtectedRoute><Assistant /></ProtectedRoute>} />
      <Route path="/case-tracker" element={<ProtectedRoute role="civilian"><CaseTracker /></ProtectedRoute>} />
      <Route path="/memory-bank" element={<ProtectedRoute role="civilian"><MemoryBank /></ProtectedRoute>} />
      <Route path="/emergency" element={<ProtectedRoute><Emergency /></ProtectedRoute>} />
      <Route path="/chat-lawyer" element={<ProtectedRoute role="civilian"><ChatLawyer /></ProtectedRoute>} />

      {/* Lawyer */}
      <Route path="/lawyer/dashboard" element={<ProtectedRoute role="lawyer"><LawyerDashboard /></ProtectedRoute>} />
      <Route path="/lawyer/cases" element={<ProtectedRoute role="lawyer"><LawyerCases /></ProtectedRoute>} />
      <Route path="/lawyer/hearings" element={<ProtectedRoute role="lawyer"><LawyerHearings /></ProtectedRoute>} />
      <Route path="/lawyer/documents" element={<ProtectedRoute role="lawyer"><LawyerDocuments /></ProtectedRoute>} />
      <Route path="/lawyer/ai-summarizer" element={<ProtectedRoute role="lawyer"><AISummarizer /></ProtectedRoute>} />
      <Route path="/lawyer/section-recommender" element={<ProtectedRoute role="lawyer"><SectionRecommender /></ProtectedRoute>} />
      <Route path="/lawyer/draft-generator" element={<ProtectedRoute role="lawyer"><DraftGenerator /></ProtectedRoute>} />
      <Route path="/lawyer/client-chat" element={<ProtectedRoute role="lawyer"><ClientChat /></ProtectedRoute>} />
      <Route path="/lawyer/analytics" element={<ProtectedRoute role="lawyer"><Analytics /></ProtectedRoute>} />

      {/* 404 */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
