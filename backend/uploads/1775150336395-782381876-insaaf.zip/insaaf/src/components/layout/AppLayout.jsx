import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';
import styles from './AppLayout.module.css';

const pageTitles = {
  '/dashboard': 'Dashboard',
  '/law-search': 'Law Search',
  '/assistant': 'AI Assistant',
  '/case-tracker': 'Case Tracker',
  '/memory-bank': 'Memory Bank',
  '/emergency': 'Emergency',
  '/chat-lawyer': 'Chat with Lawyer',
  '/lawyer/dashboard': 'Lawyer Dashboard',
  '/lawyer/cases': 'Case Management',
  '/lawyer/hearings': 'Hearings',
  '/lawyer/documents': 'Document Vault',
  '/lawyer/ai-summarizer': 'AI Summarizer',
  '/lawyer/section-recommender': 'Section Recommender',
  '/lawyer/draft-generator': 'Draft Generator',
  '/lawyer/client-chat': 'Client Chat',
  '/lawyer/analytics': 'Analytics',
};

function useBreakpoint() {
  const [bp, setBp] = useState(() => {
    if (typeof window === 'undefined') return 'desktop';
    if (window.innerWidth < 768) return 'mobile';
    if (window.innerWidth < 1024) return 'tablet';
    return 'desktop';
  });
  useEffect(() => {
    const handler = () => {
      const w = window.innerWidth;
      setBp(w < 768 ? 'mobile' : w < 1024 ? 'tablet' : 'desktop');
    };
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);
  return bp;
}

export default function AppLayout({ children }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const bp = useBreakpoint();

  // Auto-collapse on tablet
  useEffect(() => {
    if (bp === 'tablet') setCollapsed(true);
    else if (bp === 'desktop') setCollapsed(false);
  }, [bp]);

  // Close mobile menu on route change
  useEffect(() => { setMenuOpen(false); }, [location.pathname]);

  const title = pageTitles[location.pathname] || '';

  return (
    <div className={`${styles.layout} ${collapsed ? styles.collapsed : ''}`}>
      <Sidebar
        isOpen={menuOpen}
        onClose={() => setMenuOpen(false)}
        collapsed={collapsed && bp !== 'mobile'}
        onCollapse={() => setCollapsed(c => !c)}
      />
      <div className={styles.main}>
        <Header
          onMenuToggle={() => setMenuOpen(o => !o)}
          menuOpen={menuOpen}
          title={title}
        />
        <main className={styles.content}>
          {children}
        </main>
      </div>
    </div>
  );
}
