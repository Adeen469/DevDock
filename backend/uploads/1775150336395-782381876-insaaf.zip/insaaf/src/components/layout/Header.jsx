import { Menu, X } from 'lucide-react';
import ThemeToggle from '../ui/ThemeToggle';
import NotificationBell from '../ui/NotificationBell';
import styles from './Header.module.css';

export default function Header({ onMenuToggle, menuOpen, title }) {
  return (
    <header className={styles.header}>
      <div className={styles.left}>
        <button className={styles.menuBtn} onClick={onMenuToggle} aria-label="Toggle menu">
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        {title && <h2 className={styles.pageTitle}>{title}</h2>}
      </div>
      <div className={styles.right}>
        <ThemeToggle />
        <NotificationBell />
      </div>
    </header>
  );
}
