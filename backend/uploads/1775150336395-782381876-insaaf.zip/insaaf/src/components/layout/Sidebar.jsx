import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Search, MessageSquare, FolderOpen, BookMarked,
  AlertTriangle, MessagesSquare, Scale, ChevronLeft, ChevronRight,
  Briefcase, Calendar, FileText, Zap, BarChart2, PenTool, LogOut,
  Users
} from 'lucide-react';
import InsaafLogo from '../ui/InsaafLogo';
import { useAuth } from '../../context/AuthContext';
import styles from './Sidebar.module.css';

const civilianNav = [
  { icon: <LayoutDashboard size={18} />, label: 'Dashboard', to: '/dashboard' },
  { icon: <Search size={18} />, label: 'Law Search', to: '/law-search' },
  { icon: <MessageSquare size={18} />, label: 'AI Assistant', to: '/assistant' },
  { icon: <FolderOpen size={18} />, label: 'Case Tracker', to: '/case-tracker' },
  { icon: <BookMarked size={18} />, label: 'Memory Bank', to: '/memory-bank' },
  { icon: <AlertTriangle size={18} />, label: 'Emergency', to: '/emergency' },
  { icon: <MessagesSquare size={18} />, label: 'Chat with Lawyer', to: '/chat-lawyer' },
];

const lawyerNav = [
  { icon: <LayoutDashboard size={18} />, label: 'Dashboard', to: '/lawyer/dashboard' },
  { icon: <Briefcase size={18} />, label: 'Cases', to: '/lawyer/cases' },
  { icon: <Calendar size={18} />, label: 'Hearings', to: '/lawyer/hearings' },
  { icon: <FileText size={18} />, label: 'Documents', to: '/lawyer/documents' },
  { divider: true, label: 'AI TOOLS' },
  { icon: <Zap size={18} />, label: 'AI Summarizer', to: '/lawyer/ai-summarizer' },
  { icon: <Scale size={18} />, label: 'Section Recommender', to: '/lawyer/section-recommender' },
  { icon: <PenTool size={18} />, label: 'Draft Generator', to: '/lawyer/draft-generator' },
  { divider: true, label: 'CLIENTS' },
  { icon: <Users size={18} />, label: 'Client Chat', to: '/lawyer/client-chat' },
  { icon: <BarChart2 size={18} />, label: 'Analytics', to: '/lawyer/analytics' },
];

export default function Sidebar({ isOpen, onClose, collapsed, onCollapse }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const nav = user?.role === 'lawyer' ? lawyerNav : civilianNav;

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <>
      {isOpen && <div className={styles.backdrop} onClick={onClose} />}
      <aside className={`${styles.sidebar} ${isOpen ? styles.open : ''} ${collapsed ? styles.collapsed : ''}`}>
        {/* Logo row */}
        <div className={styles.header}>
          {collapsed
            ? <InsaafLogo size={26} showText={false} />
            : <InsaafLogo size={28} />
          }
          <button
            className={styles.collapseBtn}
            onClick={onCollapse}
            title={collapsed ? 'Expand' : 'Collapse'}
          >
            {collapsed ? <ChevronRight size={15} /> : <ChevronLeft size={15} />}
          </button>
        </div>

        {/* User card */}
        {!collapsed && user && (
          <div className={styles.userCard}>
            <div className={styles.avatar}>
              {user.name?.charAt(0).toUpperCase()}
            </div>
            <div className={styles.userInfo}>
              <div className={styles.userName}>{user.name}</div>
              <div className={styles.userRole}>
                {user.role === 'lawyer' ? '⚖️ Advocate' : '👤 Citizen'}
              </div>
            </div>
          </div>
        )}

        {/* Nav */}
        <nav className={styles.nav}>
          {nav.map((item, idx) => {
            if (item.divider) {
              return collapsed ? (
                <div key={idx} className={styles.dividerCollapsed} />
              ) : (
                <div key={idx} className={styles.dividerLabel}>{item.label}</div>
              );
            }
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `${styles.navItem} ${isActive ? styles.active : ''} ${collapsed ? styles.navItemCollapsed : ''}`
                }
                onClick={onClose}
                title={collapsed ? item.label : undefined}
              >
                <span className={styles.navIcon}>{item.icon}</span>
                {!collapsed && <span className={styles.navText}>{item.label}</span>}
              </NavLink>
            );
          })}
        </nav>

        {/* Footer */}
        <div className={styles.footer}>
          <button
            className={`${styles.navItem} ${styles.logoutBtn} ${collapsed ? styles.navItemCollapsed : ''}`}
            onClick={handleLogout}
            title={collapsed ? 'Logout' : undefined}
          >
            <span className={styles.navIcon}><LogOut size={18} /></span>
            {!collapsed && <span className={styles.navText}>Logout</span>}
          </button>
        </div>
      </aside>
    </>
  );
}
