import styles from './Card.module.css';

export default function Card({ children, className = '', hover = false, padding = 'md', onClick, style }) {
  return (
    <div
      className={`${styles.card} ${styles[padding]} ${hover ? styles.hover : ''} ${onClick ? styles.clickable : ''} ${className}`}
      onClick={onClick}
      style={style}
    >
      {children}
    </div>
  );
}
