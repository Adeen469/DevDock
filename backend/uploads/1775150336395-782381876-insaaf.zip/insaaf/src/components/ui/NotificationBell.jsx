import { useState } from 'react';
import { Bell, X, AlertCircle, Calendar, Zap } from 'lucide-react';
import { mockNotifications } from '../../data/mockData';
import styles from './NotificationBell.module.css';

const iconMap = {
  hearing: <Calendar size={14} />,
  update: <AlertCircle size={14} />,
  ai: <Zap size={14} />,
};

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState(mockNotifications);
  const unread = notifications.filter(n => !n.read).length;

  const markAllRead = () => setNotifications(n => n.map(x => ({ ...x, read: true })));

  return (
    <div className={styles.wrap}>
      <button className={styles.bell} onClick={() => setOpen(o => !o)}>
        <Bell size={18} />
        {unread > 0 && <span className={styles.badge}>{unread}</span>}
      </button>

      {open && (
        <>
          <div className={styles.backdrop} onClick={() => setOpen(false)} />
          <div className={styles.panel}>
            <div className={styles.panelHeader}>
              <span className={styles.panelTitle}>Notifications</span>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                {unread > 0 && (
                  <button className={styles.markRead} onClick={markAllRead}>Mark all read</button>
                )}
                <button className={styles.closeBtn} onClick={() => setOpen(false)}>
                  <X size={14} />
                </button>
              </div>
            </div>
            <div className={styles.list}>
              {notifications.length === 0 ? (
                <div className={styles.empty}>No notifications</div>
              ) : (
                notifications.map(n => (
                  <div key={n.id} className={`${styles.item} ${!n.read ? styles.unread : ''}`}>
                    <div className={`${styles.nIcon} ${styles[n.type]}`}>{iconMap[n.type]}</div>
                    <div className={styles.nContent}>
                      <div className={styles.nTitle}>{n.title}</div>
                      <div className={styles.nMsg}>{n.message}</div>
                      <div className={styles.nTime}>{n.time}</div>
                    </div>
                    {!n.read && <div className={styles.dot} />}
                  </div>
                ))
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
