import styles from './RiskScore.module.css';

export default function RiskScore({ score = 0, size = 'md' }) {
  const level = score < 34 ? 'low' : score < 67 ? 'medium' : 'high';
  const label = level === 'low' ? 'Low Risk' : level === 'medium' ? 'Medium Risk' : 'High Risk';
  const color = level === 'low' ? 'var(--success)' : level === 'medium' ? 'var(--warning)' : 'var(--danger)';
  const circumference = 2 * Math.PI * 36;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className={`${styles.wrap} ${styles[size]}`}>
      <svg viewBox="0 0 88 88" className={styles.ring}>
        <circle cx="44" cy="44" r="36" className={styles.track} />
        <circle
          cx="44" cy="44" r="36"
          className={styles.fill}
          style={{
            strokeDasharray: circumference,
            strokeDashoffset: offset,
            stroke: color,
          }}
        />
      </svg>
      <div className={styles.inner}>
        <span className={styles.score} style={{ color }}>{score}</span>
        <span className={styles.label}>{label}</span>
      </div>
    </div>
  );
}
