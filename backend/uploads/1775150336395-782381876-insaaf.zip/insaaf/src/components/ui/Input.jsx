import styles from './Input.module.css';

export default function Input({
  label,
  error,
  icon,
  iconRight,
  hint,
  className = '',
  full = true,
  ...props
}) {
  return (
    <div className={`${styles.wrapper} ${full ? styles.full : ''} ${className}`}>
      {label && <label className={styles.label}>{label}</label>}
      <div className={`${styles.inputWrap} ${error ? styles.hasError : ''}`}>
        {icon && <span className={styles.iconLeft}>{icon}</span>}
        <input className={`${styles.input} ${icon ? styles.withIconLeft : ''} ${iconRight ? styles.withIconRight : ''}`} {...props} />
        {iconRight && <span className={styles.iconRight}>{iconRight}</span>}
      </div>
      {error && <span className={styles.error}>{error}</span>}
      {hint && !error && <span className={styles.hint}>{hint}</span>}
    </div>
  );
}

export function Textarea({ label, error, hint, className = '', full = true, ...props }) {
  return (
    <div className={`${styles.wrapper} ${full ? styles.full : ''} ${className}`}>
      {label && <label className={styles.label}>{label}</label>}
      <div className={`${styles.inputWrap} ${error ? styles.hasError : ''}`}>
        <textarea className={`${styles.input} ${styles.textarea}`} {...props} />
      </div>
      {error && <span className={styles.error}>{error}</span>}
      {hint && !error && <span className={styles.hint}>{hint}</span>}
    </div>
  );
}
