import styles from './Timeline.module.css';

export default function Timeline({ events = [] }) {
  return (
    <div className={styles.timeline}>
      {events.map((event, i) => (
        <div key={event.id || i} className={`${styles.item} ${i === events.length - 1 ? styles.last : ''}`}>
          <div className={styles.left}>
            <div className={`${styles.dot} ${styles[event.type || 'default']}`}>
              {event.icon}
            </div>
            {i < events.length - 1 && <div className={styles.line} />}
          </div>
          <div className={styles.content}>
            <div className={styles.header}>
              <span className={styles.title}>{event.title}</span>
              <span className={styles.time}>{event.time || event.date}</span>
            </div>
            {event.description && (
              <p className={styles.desc}>{event.description}</p>
            )}
            {event.tags && (
              <div className={styles.tags}>
                {event.tags.map((tag, j) => (
                  <span key={j} className={styles.tag}>{tag}</span>
                ))}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
