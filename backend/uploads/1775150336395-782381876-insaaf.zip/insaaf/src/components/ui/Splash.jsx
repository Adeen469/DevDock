import styles from './Splash.module.css';

export default function Splash() {
  return (
    <div className={styles.splash}>
      <div className={styles.logoWrap}>
        <svg width="52" height="52" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className={styles.logoSvg}>
          <line x1="20" y1="10" x2="20" y2="34" stroke="#c9a84c" strokeWidth="2" strokeLinecap="round"/>
          <circle cx="20" cy="10" r="2.5" fill="#c9a84c"/>
          <line x1="6" y1="16" x2="34" y2="16" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
          <line x1="8" y1="16" x2="8" y2="24" stroke="#888" strokeWidth="1.2" strokeLinecap="round"/>
          <line x1="32" y1="16" x2="32" y2="24" stroke="#888" strokeWidth="1.2" strokeLinecap="round"/>
          <path d="M4 24 Q8 27 12 24" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
          <path d="M28 25 Q32 28 36 25" stroke="#c9a84c" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
          <line x1="20" y1="14" x2="20" y2="32" stroke="#c9a84c" strokeWidth="2.5" strokeLinecap="round"/>
          <line x1="17" y1="34" x2="23" y2="34" stroke="#c9a84c" strokeWidth="2" strokeLinecap="round"/>
        </svg>
        <span className={styles.logoText}>Insaaf</span>
      </div>
      <div className={styles.bar}>
        <div className={styles.fill} />
      </div>
    </div>
  );
}
