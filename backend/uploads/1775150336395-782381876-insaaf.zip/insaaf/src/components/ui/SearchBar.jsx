import { useState } from 'react';
import { Search, X } from 'lucide-react';
import styles from './SearchBar.module.css';

export default function SearchBar({ placeholder = 'Search...', onSearch, value, onChange, className = '' }) {
  const [internal, setInternal] = useState('');
  const val = value !== undefined ? value : internal;
  const setVal = onChange || setInternal;

  const handleClear = () => {
    setVal('');
    onSearch?.('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') onSearch?.(val);
  };

  return (
    <div className={`${styles.wrap} ${className}`}>
      <Search size={16} className={styles.icon} />
      <input
        className={styles.input}
        placeholder={placeholder}
        value={val}
        onChange={e => setVal(e.target.value)}
        onKeyDown={handleKeyDown}
      />
      {val && (
        <button className={styles.clear} onClick={handleClear}>
          <X size={14} />
        </button>
      )}
    </div>
  );
}
