import styles from './StatCard.module.css';

export default function StatCard({ label, value, sub, icon, trend, trendUp, accentColor, className = '' }) {
  return (
    <div className={`${styles.card} ${className}`}>
      <div className={styles.top}>
        <span className={styles.label}>{label}</span>
        {icon && (
          <div className={styles.iconWrap} style={accentColor ? { background: `${accentColor}18`, color: accentColor } : {}}>
            {icon}
          </div>
        )}
      </div>
      <div className={styles.value} style={accentColor ? { color: accentColor } : {}}>{value}</div>
      <div className={styles.bottom}>
        {sub && <span className={styles.sub}>{sub}</span>}
        {trend && (
          <span className={`${styles.trend} ${trendUp ? styles.up : styles.down}`}>
            {trendUp ? '↑' : '↓'} {trend}
          </span>
        )}
      </div>
    </div>
  );
}
