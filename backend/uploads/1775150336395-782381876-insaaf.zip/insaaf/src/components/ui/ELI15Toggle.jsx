import { useState } from 'react';
import { Sparkles } from 'lucide-react';
import styles from './ELI15Toggle.module.css';

export default function ELI15Toggle({ onToggle }) {
  const [active, setActive] = useState(false);
  const toggle = () => {
    setActive(a => !a);
    onToggle?.(!active);
  };
  return (
    <button
      className={`${styles.btn} ${active ? styles.active : ''}`}
      onClick={toggle}
      title="Explain Like I'm 15 — simple plain language"
    >
      <Sparkles size={13} />
      <span>ELI15</span>
    </button>
  );
}
