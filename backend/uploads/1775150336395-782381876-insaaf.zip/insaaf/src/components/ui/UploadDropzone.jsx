import { useState, useRef } from 'react';
import { Upload, X, FileText, Image, File } from 'lucide-react';
import styles from './UploadDropzone.module.css';

const fileIcon = (name) => {
  if (!name) return <File size={16} />;
  const ext = name.split('.').pop().toLowerCase();
  if (['jpg','jpeg','png','gif','webp'].includes(ext)) return <Image size={16} />;
  if (ext === 'pdf') return <FileText size={16} />;
  return <File size={16} />;
};

export default function UploadDropzone({ onFiles, accept = '*', multiple = true, label = 'Drop files here or click to upload' }) {
  const [dragging, setDragging] = useState(false);
  const [files, setFiles] = useState([]);
  const inputRef = useRef();

  const handleFiles = (incoming) => {
    const arr = Array.from(incoming);
    setFiles(f => [...f, ...arr]);
    onFiles?.(arr);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const remove = (idx) => setFiles(f => f.filter((_, i) => i !== idx));

  return (
    <div className={styles.wrap}>
      <div
        className={`${styles.zone} ${dragging ? styles.dragging : ''}`}
        onDragOver={e => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
      >
        <input
          ref={inputRef}
          type="file"
          multiple={multiple}
          accept={accept}
          style={{ display: 'none' }}
          onChange={e => handleFiles(e.target.files)}
        />
        <Upload size={24} className={styles.uploadIcon} />
        <span className={styles.label}>{label}</span>
        <span className={styles.sub}>PDF, DOC, JPG, PNG up to 20MB</span>
      </div>

      {files.length > 0 && (
        <div className={styles.fileList}>
          {files.map((f, i) => (
            <div key={i} className={styles.file}>
              <span className={styles.fileIcon}>{fileIcon(f.name)}</span>
              <span className={styles.fileName}>{f.name}</span>
              <span className={styles.fileSize}>{(f.size / 1024).toFixed(0)} KB</span>
              <button className={styles.remove} onClick={() => remove(i)}>
                <X size={12} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
