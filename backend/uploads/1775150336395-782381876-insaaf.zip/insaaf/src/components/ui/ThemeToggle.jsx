import { Sun, Moon } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import styles from './ThemeToggle.module.css';

export default function ThemeToggle() {
  const { isDark, toggle } = useTheme();
  return (
    <button
      className={styles.toggle}
      onClick={toggle}
      aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
      title={isDark ? 'Light mode' : 'Dark mode'}
    >
      <div className={`${styles.track} ${isDark ? styles.dark : styles.light}`}>
        <div className={styles.thumb}>
          {isDark ? <Moon size={12} /> : <Sun size={12} />}
        </div>
      </div>
    </button>
  );
}
