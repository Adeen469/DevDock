export default function InsaafLogo({ size = 32, showText = true, className = '' }) {
  return (
    <div className={`insaaf-logo ${className}`} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
      <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Scale beam */}
        <line x1="20" y1="10" x2="20" y2="34" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round"/>
        {/* Center pivot */}
        <circle cx="20" cy="10" r="2.5" fill="var(--accent)"/>
        {/* Horizontal beam */}
        <line x1="6" y1="16" x2="34" y2="16" stroke="var(--text)" strokeWidth="1.5" strokeLinecap="round"/>
        {/* Left pan string */}
        <line x1="8" y1="16" x2="8" y2="24" stroke="var(--text-secondary)" strokeWidth="1.2" strokeLinecap="round"/>
        {/* Right pan string */}
        <line x1="32" y1="16" x2="32" y2="24" stroke="var(--text-secondary)" strokeWidth="1.2" strokeLinecap="round"/>
        {/* Left pan */}
        <path d="M4 24 Q8 27 12 24" stroke="var(--text)" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
        {/* Right pan (slightly lower = weighted) */}
        <path d="M28 25 Q32 28 36 25" stroke="var(--accent)" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
        {/* Letter I integrated */}
        <line x1="20" y1="14" x2="20" y2="32" stroke="var(--accent)" strokeWidth="2.5" strokeLinecap="round"/>
        <line x1="17" y1="34" x2="23" y2="34" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round"/>
        {/* Top dot of I */}
        <circle cx="20" cy="10" r="2" fill="var(--accent)"/>
      </svg>
      {showText && (
        <span style={{
          fontFamily: 'var(--font-display)',
          fontWeight: 800,
          fontSize: size * 0.55,
          letterSpacing: '-0.03em',
          color: 'var(--text)',
          lineHeight: 1,
        }}>
          Insaaf
        </span>
      )}
    </div>
  );
}
