import { useState } from 'react';
import { Calendar, Clock, MapPin, User, Plus, CheckCircle, XCircle } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import Tabs from '../../components/ui/Tabs';
import Modal from '../../components/ui/Modal';
import Input from '../../components/ui/Input';
import { mockHearings } from '../../data/mockData';
import styles from './LawyerHearings.module.css';

export default function LawyerHearings() {
  const [tab, setTab] = useState('upcoming');
  const [addModal, setAddModal] = useState(false);

  const filtered = mockHearings.filter(h => h.status === tab || tab === 'all');

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <div>
            <h1 className={styles.pageTitle}>Hearing Manager</h1>
            <p className={styles.pageSub}>Track all your scheduled and past court dates</p>
          </div>
          <Button icon={<Plus size={15} />} onClick={() => setAddModal(true)}>Add Hearing</Button>
        </div>

        <Tabs
          tabs={[
            { id: 'upcoming', label: 'Upcoming', count: mockHearings.filter(h => h.status === 'upcoming').length },
            { id: 'completed', label: 'Completed', count: mockHearings.filter(h => h.status === 'completed').length },
            { id: 'all', label: 'All' },
          ]}
          onChange={setTab}
        />

        <div className={styles.hearingGrid}>
          {filtered.map(h => (
            <Card key={h.id} hover className={styles.hearingCard}>
              <div className={styles.cardLeft}>
                <div className={`${styles.dateBlock} ${h.status === 'upcoming' ? styles.upcomingDate : styles.doneDate}`}>
                  <span className={styles.dateDay}>{new Date(h.date).toLocaleDateString('en-IN', { day: 'numeric' })}</span>
                  <span className={styles.dateMonth}>{new Date(h.date).toLocaleDateString('en-IN', { month: 'short' })}</span>
                  <span className={styles.dateYear}>{new Date(h.date).toLocaleDateString('en-IN', { year: 'numeric' })}</span>
                </div>
              </div>
              <div className={styles.cardBody}>
                <div className={styles.hearingTop}>
                  <h3 className={styles.hearingTitle}>{h.caseTitle}</h3>
                  {h.status === 'upcoming'
                    ? <Badge variant="warning" dot>Upcoming</Badge>
                    : <Badge variant="success"><CheckCircle size={10} /> Done</Badge>
                  }
                </div>
                <div className={styles.hearingMeta}>
                  <span className={styles.metaItem}><Clock size={13} />{h.time}</span>
                  <span className={styles.metaItem}><MapPin size={13} />{h.court}</span>
                  <span className={styles.metaItem}><User size={13} />{h.judge}</span>
                </div>
                {h.status === 'upcoming' && (
                  <div className={styles.actions}>
                    <Button size="sm" variant="outline" icon={<CheckCircle size={13} />}>Mark Done</Button>
                    <Button size="sm" variant="ghost" icon={<XCircle size={13} />}>Adjourn</Button>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>

        <Modal
          isOpen={addModal}
          onClose={() => setAddModal(false)}
          title="Schedule Hearing"
          size="md"
          footer={
            <>
              <Button variant="secondary" onClick={() => setAddModal(false)}>Cancel</Button>
              <Button onClick={() => setAddModal(false)}>Schedule</Button>
            </>
          }
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Input label="Case Title" placeholder="Select or type case name" />
            <Input label="Hearing Date" type="date" />
            <Input label="Hearing Time" type="time" />
            <Input label="Court Name" placeholder="e.g. Labour Court, Pune, Room 4" />
            <Input label="Judge / Bench" placeholder="Hon. Judge Name" />
            <Input label="Notes" placeholder="What to prepare, documents needed..." />
          </div>
        </Modal>
      </div>
    </AppLayout>
  );
}
