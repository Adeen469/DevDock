import { useNavigate } from 'react-router-dom';
import { Briefcase, Calendar, FileText, TrendingUp, Users, Clock, ChevronRight, AlertCircle } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import StatCard from '../../components/ui/StatCard';
import Card from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import { mockLawyerCases, mockHearings } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';
import styles from './LawyerDashboard.module.css';

const statusVariant = { active: 'success', pending: 'warning', closed: 'default' };

export default function LawyerDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const upcoming = mockHearings.filter(h => h.status === 'upcoming');

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.greeting}>
          <div>
            <h1 className={styles.greetingTitle}>Good morning, {user?.name?.split(' ').slice(0,2).join(' ')} ⚖️</h1>
            <p className={styles.greetingSub}>
              {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </p>
          </div>
          <Button onClick={() => navigate('/lawyer/cases')}>+ New Case</Button>
        </div>

        <div className={styles.statsGrid}>
          <StatCard label="Active Cases" value="51" sub="Across all courts" icon={<Briefcase size={16} />} accentColor="var(--accent)" trend="+3 this week" trendUp />
          <StatCard label="This Month Revenue" value="₹1.34L" sub="18 matters billed" icon={<TrendingUp size={16} />} accentColor="#22c55e" trend="+14%" trendUp />
          <StatCard label="Hearings This Week" value="7" sub="Next: Tomorrow, 11AM" icon={<Calendar size={16} />} accentColor="#3b82f6" />
          <StatCard label="Pending Documents" value="4" sub="Requires attention" icon={<FileText size={16} />} accentColor="#ef4444" />
        </div>

        {/* Urgent alerts */}
        <div className={styles.alertBanner}>
          <AlertCircle size={16} />
          <span><strong>Reminder:</strong> Wage Theft case hearing at Labour Court, Pune tomorrow at 11:00 AM. Prepare wage slip evidence.</span>
          <Button size="sm" variant="outline">View Case</Button>
        </div>

        <div className={styles.twoCol}>
          {/* Recent Cases */}
          <div className={styles.section}>
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Recent Cases</h2>
              <button className={styles.seeAll} onClick={() => navigate('/lawyer/cases')}>See all →</button>
            </div>
            <div className={styles.caseList}>
              {mockLawyerCases.slice(0, 4).map(c => (
                <div key={c.id} className={styles.caseRow} onClick={() => navigate('/lawyer/cases')}>
                  <div className={styles.caseAvatar}>{c.clientName.charAt(0)}</div>
                  <div className={styles.caseInfo}>
                    <div className={styles.caseName}>{c.title}</div>
                    <div className={styles.caseMeta}>{c.clientName} · {c.court}</div>
                  </div>
                  <div className={styles.caseRight}>
                    <Badge variant={statusVariant[c.status]} size="sm">{c.stage}</Badge>
                    <ChevronRight size={14} className={styles.caseArrow} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upcoming Hearings */}
          <div className={styles.section}>
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Upcoming Hearings</h2>
              <button className={styles.seeAll} onClick={() => navigate('/lawyer/hearings')}>See all →</button>
            </div>
            <div className={styles.hearingList}>
              {upcoming.map(h => (
                <Card key={h.id} padding="sm" className={styles.hearingCard}>
                  <div className={styles.hearingDate}>
                    <span className={styles.hearingDay}>{new Date(h.date).toLocaleDateString('en-IN', { day: 'numeric' })}</span>
                    <span className={styles.hearingMonth}>{new Date(h.date).toLocaleDateString('en-IN', { month: 'short' })}</span>
                  </div>
                  <div className={styles.hearingInfo}>
                    <div className={styles.hearingTitle}>{h.caseTitle}</div>
                    <div className={styles.hearingMeta}>
                      <Clock size={11} />{h.time} · {h.court}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>

        {/* Quick AI Tools */}
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>AI Tools</h2>
          <div className={styles.aiToolsGrid}>
            {[
              { label: 'AI Case Summarizer', icon: '🤖', to: '/lawyer/ai-summarizer', desc: 'Summarize case documents instantly' },
              { label: 'Section Recommender', icon: '⚖️', to: '/lawyer/section-recommender', desc: 'Find relevant IPC/BNS sections' },
              { label: 'Draft Generator', icon: '📝', to: '/lawyer/draft-generator', desc: 'Auto-generate legal drafts' },
              { label: 'Analytics', icon: '📊', to: '/lawyer/analytics', desc: 'Practice insights & trends' },
            ].map(tool => (
              <Card key={tool.to} hover className={styles.aiTool} onClick={() => navigate(tool.to)}>
                <div className={styles.aiToolEmoji}>{tool.icon}</div>
                <div>
                  <div className={styles.aiToolName}>{tool.label}</div>
                  <div className={styles.aiToolDesc}>{tool.desc}</div>
                </div>
                <ChevronRight size={16} className={styles.aiToolArrow} />
              </Card>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
