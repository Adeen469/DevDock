import { useState } from 'react';
import { PenTool, Copy, Download, RefreshCw } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import { Textarea } from '../../components/ui/Input';
import styles from './DraftGenerator.module.css';

const draftTypes = [
  { id: 'legal_notice', label: 'Legal Notice' },
  { id: 'complaint', label: 'Police Complaint' },
  { id: 'bail_application', label: 'Bail Application' },
  { id: 'stay_application', label: 'Stay Application' },
  { id: 'vakalatnama', label: 'Vakalatnama' },
  { id: 'rejoinder', label: 'Rejoinder Affidavit' },
];

const mockDraft = `BEFORE THE LABOUR COURT, PUNE

IN THE MATTER OF:
Rani Sharma, W/o Ram Sharma, Aged 28 Years,
R/o 45, Ganesh Nagar, Hadapsar, Pune – 411 028     ...COMPLAINANT

VERSUS

ABC Garments Ltd., through its Manager,
Plot No. 12, Industrial Estate, Ranjangaon, Pune – 412 220    ...RESPONDENT

LEGAL NOTICE

To,
The Manager,
ABC Garments Ltd.

TAKE NOTICE THAT my client Rani Sharma has instructed me to issue this notice to you as follows:

1. My client was employed by you as a garment worker with effect from 01.01.2024 on a monthly wage of Rs. 8,000/- (Rupees Eight Thousand Only).

2. That despite having worked diligently, you have failed and neglected to pay my client's wages for the months of October, November and December 2024, totaling Rs. 24,000/- (Rupees Twenty Four Thousand Only).

3. That the aforesaid non-payment is in clear violation of the Payment of Wages Act, 1936, particularly Section 3 thereof, which mandates payment of wages before the 7th day of the following wage period.

4. You are hereby called upon to pay the outstanding wages amounting to Rs. 24,000/- together with interest at 6% per annum within 7 (Seven) days of receipt of this notice.

5. TAKE FURTHER NOTICE that in case of your failure to comply with this demand within the stipulated time, my client shall be constrained to initiate legal proceedings before the competent Authority under the Payment of Wages Act, 1936 and/or file a criminal complaint under BNS Section 316, entirely at your risk and cost.

Dated this __ day of March, 2025.

Sd/-
[Advocate Name]
Advocate
Enrollment No. MH/XXXX/2018`;

export default function DraftGenerator() {
  const [draftType, setDraftType] = useState('legal_notice');
  const [form, setForm] = useState({ clientName: 'Rani Sharma', opposingParty: 'ABC Garments Ltd.', facts: '', court: 'Labour Court, Pune' });
  const [draft, setDraft] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));

  const generate = async () => {
    setLoading(true);
    await new Promise(r => setTimeout(r, 1600));
    setDraft(mockDraft);
    setLoading(false);
  };

  const copy = () => {
    navigator.clipboard.writeText(draft);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <h1 className={styles.pageTitle}>Draft Generator</h1>
          <p className={styles.pageSub}>Auto-generate legal notices, applications, and court documents</p>
        </div>

        <div className={styles.layout}>
          <div className={styles.inputCol}>
            <Card padding="lg">
              <div className={styles.section}>
                <h3 className={styles.sectionTitle}>Document Type</h3>
                <div className={styles.draftTypes}>
                  {draftTypes.map(t => (
                    <button
                      key={t.id}
                      className={`${styles.typeBtn} ${draftType === t.id ? styles.typeActive : ''}`}
                      onClick={() => setDraftType(t.id)}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className={styles.section}>
                <h3 className={styles.sectionTitle}>Parties</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <Input label="Client / Complainant Name" value={form.clientName} onChange={set('clientName')} />
                  <Input label="Opposing Party" value={form.opposingParty} onChange={set('opposingParty')} />
                  <Input label="Court / Authority" value={form.court} onChange={set('court')} />
                </div>
              </div>

              <div className={styles.section}>
                <h3 className={styles.sectionTitle}>Key Facts</h3>
                <Textarea
                  placeholder="Describe the key facts to include in the draft..."
                  value={form.facts}
                  onChange={set('facts')}
                  style={{ minHeight: 100 }}
                />
              </div>

              <Button full icon={<PenTool size={15} />} loading={loading} onClick={generate} size="lg">
                {loading ? 'Generating Draft...' : 'Generate Draft'}
              </Button>
            </Card>
          </div>

          <div className={styles.outputCol}>
            <div className={styles.draftHeader}>
              <span className={styles.draftLabel}>Draft Output</span>
              {draft && (
                <div style={{ display: 'flex', gap: 8 }}>
                  <Button size="sm" variant="secondary" icon={<Copy size={13} />} onClick={copy}>
                    {copied ? 'Copied!' : 'Copy'}
                  </Button>
                  <Button size="sm" variant="secondary" icon={<Download size={13} />}>
                    Export DOCX
                  </Button>
                  <Button size="sm" variant="ghost" icon={<RefreshCw size={13} />} onClick={() => setDraft('')}>
                    Clear
                  </Button>
                </div>
              )}
            </div>
            <div className={styles.draftBody}>
              {loading && (
                <div className={styles.loadingState}>
                  <PenTool size={28} className={styles.loadingIcon} />
                  <p>Drafting document...</p>
                </div>
              )}
              {!loading && draft && (
                <pre className={styles.draftText}>{draft}</pre>
              )}
              {!loading && !draft && (
                <div className={styles.emptyState}>
                  <PenTool size={32} />
                  <p>Fill in the details and click Generate Draft</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
