import { useState } from 'react';
import { Zap, FileText, Copy, Download, RotateCcw } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { Textarea } from '../../components/ui/Input';
import UploadDropzone from '../../components/ui/UploadDropzone';
import ELI15Toggle from '../../components/ui/ELI15Toggle';
import Tabs from '../../components/ui/Tabs';
import styles from './AISummarizer.module.css';

const mockSummary = `**Case Summary — Wage Theft Matter (CNR-MH-2024-001823)**

**Parties:**
- Complainant: Rani Sharma (Garment Worker)
- Respondent: ABC Garments Ltd., Pune

**Key Facts:**
1. Complainant was employed as a garment worker from January 2024.
2. Wages were not paid for October, November, and December 2024.
3. Total unpaid amount: ₹24,000 (₹8,000/month).
4. No written explanation was provided by employer.

**Applicable Law:**
- Payment of Wages Act, 1936 — Section 15: Claim for unpaid wages.
- BNS Section 316: Cheating by misrepresentation if false promises were made.

**Current Status:**
Filed on 12 January 2025. Employer served notice on 28 January. Reply filed by employer on 18 February. Next hearing: 18 April 2025.

**Risk Assessment:** Low-Medium (32/100). Strong documentary evidence. Employer's reply is weak.

**Recommended Next Steps:**
1. Collect all wage slips and attendance registers.
2. File affidavit-in-rejoinder before next hearing.
3. Apply for interim relief under Section 15(2) if employer delays.`;

export default function AISummarizer() {
  const [tab, setTab] = useState('upload');
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState('');
  const [eli15, setEli15] = useState(false);
  const [copied, setCopied] = useState(false);

  const summarize = async () => {
    setLoading(true);
    await new Promise(r => setTimeout(r, 1800));
    setSummary(eli15
      ? `**Simple Summary — Wage Case**\n\nA worker named Rani didn't get paid for 3 months by her factory boss. That's against the law. She went to court and now the boss has to explain why. The next court date is April 18. She has a good chance of winning because she has proof.\n\n**What should happen next:** She needs to bring her pay slips and attendance records to court.`
      : mockSummary
    );
    setLoading(false);
  };

  const copy = () => {
    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <div>
            <h1 className={styles.pageTitle}>AI Case Summarizer</h1>
            <p className={styles.pageSub}>Instantly summarize case documents, FIRs, and legal briefs</p>
          </div>
          <ELI15Toggle onToggle={setEli15} />
        </div>

        <div className={styles.layout}>
          <div className={styles.inputCol}>
            <Tabs
              tabs={[
                { id: 'upload', label: 'Upload Document', icon: <FileText size={13} /> },
                { id: 'paste', label: 'Paste Text', icon: <FileText size={13} /> },
              ]}
              onChange={setTab}
            />

            {tab === 'upload' ? (
              <UploadDropzone label="Drop your case document here (PDF, DOC, TXT)" accept=".pdf,.doc,.docx,.txt" />
            ) : (
              <Textarea
                label="Paste document text"
                placeholder="Paste the full text of your case document, FIR, or legal brief here..."
                value={text}
                onChange={e => setText(e.target.value)}
                style={{ minHeight: 240 }}
              />
            )}

            <div className={styles.options}>
              <div className={styles.optionRow}>
                <span className={styles.optionLabel}>Summary Length</span>
                <select className={styles.select}>
                  <option>Concise (1 page)</option>
                  <option>Detailed (2-3 pages)</option>
                  <option>Bullet points only</option>
                </select>
              </div>
              <div className={styles.optionRow}>
                <span className={styles.optionLabel}>AI Model</span>
                <select className={styles.select}>
                  <option>GPT-4o (Recommended)</option>
                  <option>Claude Sonnet</option>
                </select>
              </div>
            </div>

            <Button icon={<Zap size={15} />} loading={loading} onClick={summarize} full size="lg">
              {loading ? 'Summarizing...' : 'Generate Summary'}
            </Button>
          </div>

          <div className={styles.outputCol}>
            <div className={styles.outputHeader}>
              <span className={styles.outputTitle}>Summary</span>
              {summary && (
                <div style={{ display: 'flex', gap: 8 }}>
                  <Button size="sm" variant="secondary" icon={<Copy size={13} />} onClick={copy}>
                    {copied ? 'Copied!' : 'Copy'}
                  </Button>
                  <Button size="sm" variant="secondary" icon={<Download size={13} />}>Export</Button>
                  <Button size="sm" variant="ghost" icon={<RotateCcw size={13} />} onClick={() => setSummary('')}>Clear</Button>
                </div>
              )}
            </div>

            <div className={styles.outputBody}>
              {loading && (
                <div className={styles.loadingState}>
                  <div className={styles.loadingDots}><span /><span /><span /></div>
                  <p>Analyzing document and generating summary...</p>
                </div>
              )}
              {!loading && summary && (
                <div className={styles.summaryText}>
                  {summary.split('\n').map((line, i) => {
                    if (line.startsWith('**') && line.endsWith('**')) {
                      return <h3 key={i} className={styles.sumHeading}>{line.replace(/\*\*/g, '')}</h3>;
                    }
                    if (line.startsWith('- ') || line.match(/^\d+\./)) {
                      return <p key={i} className={styles.sumBullet} dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />;
                    }
                    if (line === '') return <div key={i} style={{ height: 8 }} />;
                    return <p key={i} className={styles.sumPara} dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />;
                  })}
                </div>
              )}
              {!loading && !summary && (
                <div className={styles.emptyState}>
                  <Zap size={32} />
                  <p>Upload a document or paste text, then click Generate Summary</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
