import { useState } from 'react';
import { Scale, Search, ChevronRight, Sparkles, BookOpen } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Badge from '../../components/ui/Badge';
import { Textarea } from '../../components/ui/Input';
import ELI15Toggle from '../../components/ui/ELI15Toggle';
import styles from './SectionRecommender.module.css';

const mockRecommendations = [
  {
    code: 'BNS § 316',
    title: 'Cheating and Dishonestly Inducing Delivery',
    relevance: 98,
    category: 'Criminal',
    description: 'Applies when employer made false promises about wages to induce work. High relevance for wage theft cases with written agreements.',
    elements: ['False promise or misrepresentation', 'Intent to deceive', 'Victim acted on representation', 'Resultant loss or damage'],
    replaces: 'IPC § 420',
  },
  {
    code: 'Payment of Wages Act § 15',
    title: 'Claims arising out of deductions from wages',
    relevance: 96,
    category: 'Labour',
    description: 'Primary section for unpaid wages. Complaint filed before Authority under Payment of Wages Act. Award can include up to 10x unpaid wages as compensation.',
    elements: ['Employment relationship established', 'Wages due and unpaid', 'Claim within 12 months', 'Prescribed authority jurisdiction'],
    replaces: null,
  },
  {
    code: 'BNS § 61',
    title: 'Criminal Conspiracy',
    relevance: 72,
    category: 'Criminal',
    description: 'If multiple persons (e.g. manager and owner) conspired to withhold wages. Secondary charge applicable where multiple accused are involved.',
    elements: ['Two or more persons', 'Agreement to commit offence', 'Overt act in furtherance'],
    replaces: 'IPC § 120-B',
  },
];

export default function SectionRecommender() {
  const [situation, setSituation] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);
  const [eli15, setEli15] = useState(false);

  const search = async () => {
    if (!situation.trim()) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1400));
    setResults(mockRecommendations);
    setLoading(false);
  };

  const exampleSituations = [
    'Employer refused to pay wages for 3 months',
    'Landlord illegally evicted tenant without notice',
    'Cheque issued by client bounced twice',
    'Employee dismissed without due process',
  ];

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <div>
            <h1 className={styles.pageTitle}>Section Recommender</h1>
            <p className={styles.pageSub}>Describe a situation and get relevant IPC / BNS / Special Law sections instantly</p>
          </div>
          <ELI15Toggle onToggle={setEli15} />
        </div>

        <Card padding="lg" className={styles.inputCard}>
          <Textarea
            label="Describe the situation or facts"
            placeholder="e.g. My client's employer has not paid wages for three months, claiming business losses. The employer had made a written promise of payment..."
            value={situation}
            onChange={e => setSituation(e.target.value)}
            style={{ minHeight: 120 }}
          />
          <div className={styles.examples}>
            <span className={styles.examplesLabel}>Try:</span>
            {exampleSituations.map(ex => (
              <button key={ex} className={styles.exampleChip} onClick={() => setSituation(ex)}>
                {ex}
              </button>
            ))}
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 4 }}>
            <Button icon={<Scale size={15} />} loading={loading} onClick={search}>
              Find Sections
            </Button>
          </div>
        </Card>

        {results.length > 0 && (
          <div className={styles.results}>
            <div className={styles.resultsHeader}>
              <h2 className={styles.resultsTitle}>
                <Sparkles size={16} style={{ color: 'var(--accent)' }} />
                {results.length} Recommended Sections
              </h2>
              <span className={styles.resultsSub}>Ranked by relevance to your situation</span>
            </div>

            <div className={styles.resultsList}>
              {results.map((r, i) => (
                <Card key={r.code} className={styles.resultCard}>
                  <div className={styles.resultTop}>
                    <div className={styles.resultLeft}>
                      <div className={styles.rankBadge}>#{i + 1}</div>
                      <div>
                        <span className={styles.resultCode}>{r.code}</span>
                        <h3 className={styles.resultTitle}>{r.title}</h3>
                      </div>
                    </div>
                    <div className={styles.resultRight}>
                      <div className={styles.relevanceWrap}>
                        <span className={styles.relevanceLabel}>Relevance</span>
                        <span className={styles.relevanceVal} style={{ color: r.relevance >= 90 ? 'var(--success)' : r.relevance >= 70 ? 'var(--warning)' : 'var(--text-secondary)' }}>
                          {r.relevance}%
                        </span>
                      </div>
                      <Badge variant={r.category === 'Criminal' ? 'danger' : r.category === 'Labour' ? 'warning' : 'info'} size="sm">
                        {r.category}
                      </Badge>
                    </div>
                  </div>

                  <p className={styles.resultDesc}>
                    {eli15
                      ? `In simple terms: This law covers exactly this kind of situation. If you use this section, the court will look at these specific things.`
                      : r.description
                    }
                  </p>

                  <div className={styles.elements}>
                    <span className={styles.elemLabel}><BookOpen size={12} />Key Elements to Prove</span>
                    <div className={styles.elemList}>
                      {r.elements.map(el => (
                        <span key={el} className={styles.elem}><ChevronRight size={10} />{el}</span>
                      ))}
                    </div>
                  </div>

                  {r.replaces && (
                    <div className={styles.replaces}>
                      Replaces <code>{r.replaces}</code> under old IPC
                    </div>
                  )}
                </Card>
              ))}
            </div>
          </div>
        )}

        {loading && (
          <div className={styles.loadingState}>
            <div className={styles.loadingSpinner} />
            <p>Searching through Indian legal database...</p>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
