import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Legend
} from 'recharts';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import StatCard from '../../components/ui/StatCard';
import { TrendingUp, Briefcase, Calendar, DollarSign } from 'lucide-react';
import { mockAnalytics } from '../../data/mockData';
import styles from './Analytics.module.css';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className={styles.tooltip}>
        <p className={styles.tooltipLabel}>{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color || 'var(--accent)' }}>
            {p.name}: {typeof p.value === 'number' && p.value > 1000 ? `₹${(p.value / 1000).toFixed(0)}K` : p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function Analytics() {
  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <h1 className={styles.pageTitle}>Practice Analytics</h1>
          <p className={styles.pageSub}>Insights into your legal practice performance</p>
        </div>

        <div className={styles.statsGrid}>
          <StatCard label="Total Cases (YTD)" value="101" icon={<Briefcase size={16} />} accentColor="var(--accent)" trend="+22% vs last year" trendUp />
          <StatCard label="Revenue (YTD)" value="₹6.12L" icon={<DollarSign size={16} />} accentColor="#22c55e" trend="+31%" trendUp />
          <StatCard label="Win Rate" value="72%" icon={<TrendingUp size={16} />} accentColor="#3b82f6" sub="28 won / 8 lost" />
          <StatCard label="Avg Case Duration" value="4.2 mo" icon={<Calendar size={16} />} accentColor="#8b5cf6" sub="Across all types" />
        </div>

        <div className={styles.chartsRow}>
          <Card padding="lg" className={styles.chartCard}>
            <h3 className={styles.chartTitle}>Monthly Revenue & Cases</h3>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={mockAnalytics.monthlyRevenue} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="month" tick={{ fill: 'var(--text-tertiary)', fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'var(--text-tertiary)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `₹${(v/1000).toFixed(0)}K`} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="revenue" fill="var(--accent)" radius={[4,4,0,0]} name="Revenue" />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card padding="lg" className={styles.chartCard}>
            <h3 className={styles.chartTitle}>Cases by Type</h3>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={mockAnalytics.casesByType}
                  cx="50%" cy="50%"
                  innerRadius={55}
                  outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {mockAnalytics.casesByType.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value, name) => [value, name]} />
              </PieChart>
            </ResponsiveContainer>
            <div className={styles.legend}>
              {mockAnalytics.casesByType.map(item => (
                <div key={item.name} className={styles.legendItem}>
                  <span className={styles.legendDot} style={{ background: item.color }} />
                  <span>{item.name}</span>
                  <span className={styles.legendVal}>{item.value}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className={styles.chartsRow}>
          <Card padding="lg" className={styles.chartCard}>
            <h3 className={styles.chartTitle}>Case Outcomes</h3>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={mockAnalytics.caseOutcomes} cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={3} dataKey="value">
                  {mockAnalytics.caseOutcomes.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className={styles.legend}>
              {mockAnalytics.caseOutcomes.map(item => (
                <div key={item.name} className={styles.legendItem}>
                  <span className={styles.legendDot} style={{ background: item.color }} />
                  <span>{item.name}</span>
                  <span className={styles.legendVal}>{item.value}</span>
                </div>
              ))}
            </div>
          </Card>

          <Card padding="lg" className={styles.chartCard}>
            <h3 className={styles.chartTitle}>Hearings per Day of Week</h3>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={mockAnalytics.hearingsByDay} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="day" tick={{ fill: 'var(--text-tertiary)', fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'var(--text-tertiary)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="count" fill="#3b82f6" radius={[4,4,0,0]} name="Hearings" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
