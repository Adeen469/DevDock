import { useState } from 'react';
import { Send, Search, CheckCheck } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import styles from './ClientChat.module.css';

const clients = [
  { id: 1, name: 'Rajesh Mehta', case: 'Property Dispute', lastMsg: 'Can you share the next hearing date?', time: '10:32 AM', unread: 2, online: true },
  { id: 2, name: 'Priya Sharma', case: 'Divorce & Custody', lastMsg: 'Thank you for the update.', time: 'Yesterday', unread: 0, online: false },
  { id: 3, name: 'TechCorp Pvt. Ltd.', case: 'Employment Termination', lastMsg: 'We have uploaded the documents.', time: 'Yesterday', unread: 1, online: false },
  { id: 4, name: 'Amit Verma', case: 'Motor Accident Claim', lastMsg: 'When should I come to your office?', time: 'Mon', unread: 0, online: true },
  { id: 5, name: 'Sonal Jain', case: 'Cheque Bounce', lastMsg: 'The cheque copy is attached.', time: 'Fri', unread: 0, online: false },
];

const convoMap = {
  1: [
    { id: 1, role: 'client', content: 'Good morning sir, can you share the next hearing date for my property case?', time: '10:28 AM' },
    { id: 2, role: 'lawyer', content: 'Good morning Rajesh ji. The next hearing is scheduled for April 20, 2025 at 11:00 AM, Family Court Room 3, Pune.', time: '10:30 AM' },
    { id: 3, role: 'client', content: 'Thank you. Do I need to be present in person?', time: '10:31 AM' },
    { id: 4, role: 'client', content: 'Can you share the next hearing date?', time: '10:32 AM' },
  ],
  2: [
    { id: 1, role: 'lawyer', content: 'The court has directed both parties to attend mediation on 15 March. Please come prepared with your financial documents.', time: 'Yesterday' },
    { id: 2, role: 'client', content: 'Thank you for the update.', time: 'Yesterday' },
  ],
};

export default function ClientChat() {
  const [selectedClient, setSelectedClient] = useState(clients[0]);
  const [messages, setMessages] = useState(convoMap[1] || []);
  const [input, setInput] = useState('');
  const [searchQ, setSearchQ] = useState('');

  const selectClient = (c) => {
    setSelectedClient(c);
    setMessages(convoMap[c.id] || []);
    setInput('');
  };

  const send = () => {
    if (!input.trim()) return;
    const msg = { id: Date.now(), role: 'lawyer', content: input, time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) };
    setMessages(m => [...m, msg]);
    setInput('');
  };

  const filtered = clients.filter(c =>
    !searchQ || c.name.toLowerCase().includes(searchQ.toLowerCase()) ||
    c.case.toLowerCase().includes(searchQ.toLowerCase())
  );

  return (
    <AppLayout>
      <div className={styles.layout}>
        {/* Client List */}
        <div className={styles.sidebar}>
          <div className={styles.sidebarHeader}>
            <h2 className={styles.sidebarTitle}>Client Messages</h2>
            <div className={styles.sidebarSearch}>
              <Search size={14} className={styles.searchIcon} />
              <input
                className={styles.searchInput}
                placeholder="Search clients..."
                value={searchQ}
                onChange={e => setSearchQ(e.target.value)}
              />
            </div>
          </div>
          <div className={styles.clientList}>
            {filtered.map(c => (
              <div
                key={c.id}
                className={`${styles.clientRow} ${selectedClient?.id === c.id ? styles.clientActive : ''}`}
                onClick={() => selectClient(c)}
              >
                <div className={styles.clientAvatar}>
                  {c.name.charAt(0)}
                  {c.online && <span className={styles.onlineDot} />}
                </div>
                <div className={styles.clientInfo}>
                  <div className={styles.clientTop}>
                    <span className={styles.clientName}>{c.name}</span>
                    <span className={styles.clientTime}>{c.time}</span>
                  </div>
                  <div className={styles.clientBottom}>
                    <span className={styles.clientLastMsg}>{c.lastMsg}</span>
                    {c.unread > 0 && <span className={styles.unreadBadge}>{c.unread}</span>}
                  </div>
                  <span className={styles.clientCase}>{c.case}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Chat Window */}
        <div className={styles.chatArea}>
          <div className={styles.chatHeader}>
            <div className={styles.chatClientAvatar}>{selectedClient?.name.charAt(0)}</div>
            <div className={styles.chatClientInfo}>
              <div className={styles.chatClientName}>{selectedClient?.name}</div>
              <div className={styles.chatClientMeta}>
                {selectedClient?.online ? <><span className={styles.onlineDotInline} />Online</> : 'Offline'} · {selectedClient?.case}
              </div>
            </div>
          </div>

          <div className={styles.chatMessages}>
            <div className={styles.dateChip}>Today</div>
            {messages.map(msg => (
              <div key={msg.id} className={`${styles.msgRow} ${msg.role === 'lawyer' ? styles.lawyerRow : styles.clientRow}`}>
                {msg.role === 'client' && (
                  <div className={styles.msgAvatar}>{selectedClient?.name.charAt(0)}</div>
                )}
                <div className={styles.msgWrap}>
                  <div className={`${styles.bubble} ${msg.role === 'lawyer' ? styles.lawyerBubble : styles.clientBubble}`}>
                    {msg.content}
                  </div>
                  <div className={styles.msgFooter}>
                    <span className={styles.msgTime}>{msg.time}</span>
                    {msg.role === 'lawyer' && <CheckCheck size={13} className={styles.readIcon} />}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className={styles.inputArea}>
            <input
              className={styles.chatInput}
              placeholder={`Message ${selectedClient?.name}...`}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && send()}
            />
            <button className={`${styles.sendBtn} ${input.trim() ? styles.sendActive : ''}`} onClick={send}>
              <Send size={16} />
            </button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
