import { useState } from 'react';
import { FileText, Image, File, Download, Trash2, Eye, Upload } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Badge from '../../components/ui/Badge';
import SearchBar from '../../components/ui/SearchBar';
import UploadDropzone from '../../components/ui/UploadDropzone';
import Modal from '../../components/ui/Modal';
import { mockDocuments } from '../../data/mockData';
import styles from './LawyerDocuments.module.css';

const fileIconMap = {
  pdf: { icon: <FileText size={20} />, color: '#ef4444' },
  txt: { icon: <FileText size={20} />, color: '#3b82f6' },
  img: { icon: <Image size={20} />, color: '#22c55e' },
};

export default function LawyerDocuments() {
  const [docs, setDocs] = useState(mockDocuments);
  const [query, setQuery] = useState('');
  const [uploadModal, setUploadModal] = useState(false);
  const [previewModal, setPreviewModal] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState(null);

  const filtered = docs.filter(d =>
    !query || d.name.toLowerCase().includes(query.toLowerCase()) ||
    d.case.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <div>
            <h1 className={styles.pageTitle}>Document Vault</h1>
            <p className={styles.pageSub}>{docs.length} documents stored securely</p>
          </div>
          <Button icon={<Upload size={15} />} onClick={() => setUploadModal(true)}>Upload</Button>
        </div>

        <SearchBar placeholder="Search documents..." value={query} onChange={setQuery} className={styles.search} />

        <div className={styles.docGrid}>
          {filtered.map(doc => {
            const ft = fileIconMap[doc.type] || { icon: <File size={20} />, color: '#888' };
            return (
              <Card key={doc.id} hover className={styles.docCard}>
                <div className={styles.docIcon} style={{ background: `${ft.color}18`, color: ft.color }}>
                  {ft.icon}
                </div>
                <div className={styles.docInfo}>
                  <div className={styles.docName}>{doc.name}</div>
                  <div className={styles.docMeta}>
                    <span>{doc.size}</span>
                    <span>·</span>
                    <Badge variant="default" size="sm">{doc.case}</Badge>
                  </div>
                  <div className={styles.docDate}>{new Date(doc.uploaded).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</div>
                </div>
                <div className={styles.docActions}>
                  <button className={styles.docBtn} title="Preview" onClick={() => { setSelectedDoc(doc); setPreviewModal(true); }}>
                    <Eye size={15} />
                  </button>
                  <button className={styles.docBtn} title="Download">
                    <Download size={15} />
                  </button>
                  <button className={`${styles.docBtn} ${styles.deleteBtn}`} title="Delete" onClick={() => setDocs(d => d.filter(x => x.id !== doc.id))}>
                    <Trash2 size={15} />
                  </button>
                </div>
              </Card>
            );
          })}
        </div>

        <Modal isOpen={uploadModal} onClose={() => setUploadModal(false)} title="Upload Documents" size="md"
          footer={<><Button variant="secondary" onClick={() => setUploadModal(false)}>Cancel</Button><Button onClick={() => setUploadModal(false)}>Upload</Button></>}>
          <UploadDropzone label="Drop your legal documents here" accept=".pdf,.doc,.docx,.jpg,.png,.txt" />
        </Modal>

        <Modal isOpen={previewModal} onClose={() => setPreviewModal(false)} title={selectedDoc?.name} size="lg">
          <div className={styles.previewPlaceholder}>
            <div className={styles.previewIcon}>
              <FileText size={48} />
            </div>
            <p className={styles.previewName}>{selectedDoc?.name}</p>
            <p className={styles.previewMeta}>{selectedDoc?.size} · Uploaded {selectedDoc?.uploaded}</p>
            <div className={styles.previewPages}>
              {[1,2,3].map(p => (
                <div key={p} className={styles.previewPage}>
                  <div className={styles.pageLines}>
                    {Array.from({ length: 8 }).map((_, i) => (
                      <div key={i} className={`${styles.pageLine} ${styles.skeleton}`} style={{ width: `${65 + Math.random() * 30}%` }} />
                    ))}
                  </div>
                  <span className={styles.pageNum}>Page {p}</span>
                </div>
              ))}
            </div>
            <Button icon={<Download size={15} />}>Download Document</Button>
          </div>
        </Modal>
      </div>
    </AppLayout>
  );
}
