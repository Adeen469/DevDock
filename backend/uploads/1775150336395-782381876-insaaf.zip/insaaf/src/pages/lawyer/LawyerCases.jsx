import { useState } from 'react';
import { Plus, Filter, Calendar, ChevronRight, Briefcase } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import SearchBar from '../../components/ui/SearchBar';
import Tabs from '../../components/ui/Tabs';
import Modal from '../../components/ui/Modal';
import Input from '../../components/ui/Input';
import { mockLawyerCases } from '../../data/mockData';
import styles from './LawyerCases.module.css';

const statusVariant = { active: 'success', pending: 'warning', closed: 'default' };
const typeColor = { Civil: '#3b82f6', Criminal: '#ef4444', Labour: '#f59e0b', Family: '#8b5cf6', Property: '#22c55e' };

export default function LawyerCases() {
  const [tab, setTab] = useState('all');
  const [query, setQuery] = useState('');
  const [addModal, setAddModal] = useState(false);

  const filtered = mockLawyerCases.filter(c => {
    const matchTab = tab === 'all' || c.status === tab;
    const matchQ = !query || c.title.toLowerCase().includes(query.toLowerCase()) || c.clientName.toLowerCase().includes(query.toLowerCase());
    return matchTab && matchQ;
  });

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <div>
            <h1 className={styles.pageTitle}>Case Management</h1>
            <p className={styles.pageSub}>{mockLawyerCases.length} total cases across all courts</p>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <Button variant="secondary" icon={<Filter size={15} />}>Filter</Button>
            <Button icon={<Plus size={15} />} onClick={() => setAddModal(true)}>New Case</Button>
          </div>
        </div>

        <div className={styles.controls}>
          <Tabs
            tabs={[
              { id: 'all', label: 'All', count: mockLawyerCases.length },
              { id: 'active', label: 'Active', count: mockLawyerCases.filter(c => c.status === 'active').length },
              { id: 'pending', label: 'Pending', count: mockLawyerCases.filter(c => c.status === 'pending').length },
            ]}
            onChange={setTab}
          />
          <SearchBar placeholder="Search by case or client..." value={query} onChange={setQuery} className={styles.search} />
        </div>

        <div className={styles.tableWrap}>
          <div className={styles.tableHeader}>
            <span>Case</span><span>Client</span><span>Type</span>
            <span>Stage</span><span>Next Hearing</span><span>Fee</span><span></span>
          </div>
          {filtered.map(c => (
            <div key={c.id} className={styles.tableRow}>
              <div className={styles.caseCell}>
                <div className={styles.caseIcon} style={{ background: `${typeColor[c.type]||'#888'}18`, color: typeColor[c.type] }}>
                  <Briefcase size={14} />
                </div>
                <div className={styles.caseCellInfo}>
                  <span className={styles.caseTitle}>{c.title}</span>
                  <Badge variant={statusVariant[c.status]} size="sm">{c.status}</Badge>
                </div>
              </div>
              <span className={styles.clientName}>{c.clientName}</span>
              <span><Badge variant="default" size="sm">{c.type}</Badge></span>
              <span className={styles.stageCell}>{c.stage}</span>
              <span className={styles.dateCell}>
                {c.nextHearing ? (
                  <span className={styles.hearingDate}><Calendar size={11}/>{new Date(c.nextHearing).toLocaleDateString('en-IN',{day:'numeric',month:'short'})}</span>
                ) : '—'}
              </span>
              <span className={styles.feeCell}>{c.fee}</span>
              <button className={styles.viewBtn}><ChevronRight size={16}/></button>
            </div>
          ))}
          {filtered.length === 0 && <div className={styles.empty}>No cases found</div>}
        </div>

        <Modal isOpen={addModal} onClose={() => setAddModal(false)} title="Add New Case" size="md"
          footer={<><Button variant="secondary" onClick={()=>setAddModal(false)}>Cancel</Button><Button onClick={()=>setAddModal(false)}>Create Case</Button></>}>
          <div style={{display:'flex',flexDirection:'column',gap:16}}>
            <Input label="Client Name" placeholder="Full name of client" />
            <Input label="Case Title" placeholder="Brief description of matter" />
            <Input label="Case / CNR Number" placeholder="Court reference number" />
            <Input label="Court Name" placeholder="e.g. High Court, Bombay" />
            <Input label="Case Type" placeholder="Civil / Criminal / Family..." />
            <Input label="Agreed Fee (₹)" type="number" placeholder="0" />
            <Input label="Next Hearing Date" type="date" />
          </div>
        </Modal>
      </div>
    </AppLayout>
  );
}
