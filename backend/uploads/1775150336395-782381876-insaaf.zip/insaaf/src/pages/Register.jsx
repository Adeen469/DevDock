import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { User, Mail, Lock, Phone } from 'lucide-react';
import InsaafLogo from '../components/ui/InsaafLogo';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import ThemeToggle from '../components/ui/ThemeToggle';
import { useAuth } from '../context/AuthContext';
import styles from './Auth.module.css';

export default function Register() {
  const [searchParams] = useSearchParams();
  const role = searchParams.get('role') || 'civilian';
  const navigate = useNavigate();
  const { login } = useAuth();

  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    login({ name: form.name || 'New User', email: form.email, role, id: 'u_new' });
    navigate(role === 'lawyer' ? '/lawyer/dashboard' : '/dashboard');
  };

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  return (
    <div className={styles.page}>
      <div className={styles.topBar}>
        <InsaafLogo size={30} />
        <ThemeToggle />
      </div>

      <div className={styles.card}>
        <div className={styles.cardHeader}>
          <div className={`${styles.rolePill} ${role === 'lawyer' ? styles.lawyer : styles.civilian}`}>
            {role === 'lawyer' ? '⚖️ Lawyer Account' : '👤 Citizen Account'}
          </div>
          <h1 className={styles.title}>Create account</h1>
          <p className={styles.sub}>Join Insaaf — free to get started</p>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          <Input label="Full name" placeholder="Your full name" icon={<User size={16} />} value={form.name} onChange={set('name')} />
          <Input label="Email address" type="email" placeholder="you@example.com" icon={<Mail size={16} />} value={form.email} onChange={set('email')} />
          <Input label="Mobile number" type="tel" placeholder="+91 9800000000" icon={<Phone size={16} />} value={form.phone} onChange={set('phone')} />
          <Input label="Password" type="password" placeholder="Create a password" icon={<Lock size={16} />} value={form.password} onChange={set('password')} hint="Minimum 8 characters" />
          {role === 'lawyer' && (
            <Input label="Bar Council Enrolment No." placeholder="e.g. MH/1234/2018" />
          )}
          <Button type="submit" full loading={loading} size="lg">Create Account</Button>
        </form>

        <div className={styles.footer}>
          Already have an account?{' '}
          <Link to={`/login?role=${role}`} className={styles.link}>Sign in</Link>
        </div>
      </div>
    </div>
  );
}
