import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';
import InsaafLogo from '../components/ui/InsaafLogo';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import ThemeToggle from '../components/ui/ThemeToggle';
import { useAuth } from '../context/AuthContext';
import styles from './Auth.module.css';

export default function Login() {
  const [searchParams] = useSearchParams();
  const role = searchParams.get('role') || 'civilian';
  const navigate = useNavigate();
  const { login } = useAuth();

  const [form, setForm] = useState({ email: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise(r => setTimeout(r, 800));
    login({
      name: role === 'lawyer' ? 'Adv. Arjun Mehta' : 'Rani Sharma',
      email: form.email || 'demo@insaaf.app',
      role,
      id: 'u1',
    });
    navigate(role === 'lawyer' ? '/lawyer/dashboard' : '/dashboard');
  };

  const demoLogin = () => {
    login({
      name: role === 'lawyer' ? 'Adv. Arjun Mehta' : 'Rani Sharma',
      email: 'demo@insaaf.app',
      role,
      id: 'u1',
    });
    navigate(role === 'lawyer' ? '/lawyer/dashboard' : '/dashboard');
  };

  return (
    <div className={styles.page}>
      <div className={styles.topBar}>
        <InsaafLogo size={30} />
        <ThemeToggle />
      </div>

      <div className={styles.card}>
        <div className={styles.cardHeader}>
          <div className={`${styles.rolePill} ${role === 'lawyer' ? styles.lawyer : styles.civilian}`}>
            {role === 'lawyer' ? '⚖️ Lawyer Login' : '👤 Citizen Login'}
          </div>
          <h1 className={styles.title}>Welcome back</h1>
          <p className={styles.sub}>Sign in to your Insaaf account</p>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          <Input
            label="Email address"
            type="email"
            placeholder="you@example.com"
            icon={<Mail size={16} />}
            value={form.email}
            onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
            autoComplete="email"
          />
          <Input
            label="Password"
            type={showPass ? 'text' : 'password'}
            placeholder="Your password"
            icon={<Lock size={16} />}
            iconRight={
              <button type="button" onClick={() => setShowPass(s => !s)} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', color: 'var(--text-secondary)' }}>
                {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            }
            value={form.password}
            onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
            autoComplete="current-password"
          />

          <Button type="submit" full loading={loading} size="lg">
            Sign In
          </Button>
        </form>

        <div className={styles.divider}><span>or</span></div>

        <Button variant="secondary" full size="lg" onClick={demoLogin}>
          🚀 Continue with Demo Account
        </Button>

        <div className={styles.footer}>
          Don't have an account?{' '}
          <Link to={`/register?role=${role}`} className={styles.link}>Create one</Link>
        </div>
        <div className={styles.footer}>
          Wrong role?{' '}
          <Link to="/" className={styles.link}>Go back</Link>
        </div>
      </div>
    </div>
  );
}
