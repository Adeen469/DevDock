import { useNavigate } from 'react-router-dom';
import { Scale, Home, ArrowLeft } from 'lucide-react';
import ThemeToggle from '../components/ui/ThemeToggle';
import Button from '../components/ui/Button';
import styles from './NotFound.module.css';

export default function NotFound() {
  const navigate = useNavigate();
  return (
    <div className={styles.page}>
      <div className={styles.topBar}>
        <Scale size={22} style={{ color: 'var(--accent)' }} />
        <ThemeToggle />
      </div>
      <div className={styles.content}>
        <div className={styles.code}>404</div>
        <h1 className={styles.title}>Page Not Found</h1>
        <p className={styles.desc}>
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className={styles.actions}>
          <Button icon={<ArrowLeft size={15} />} variant="secondary" onClick={() => navigate(-1)}>
            Go Back
          </Button>
          <Button icon={<Home size={15} />} onClick={() => navigate('/')}>
            Go Home
          </Button>
        </div>
      </div>
    </div>
  );
}
