import { useState } from 'react';
import { Send, Star, MapPin, Scale, CheckCircle } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import styles from './ChatLawyer.module.css';

const lawyers = [
  { id: 1, name: 'Adv. Priya Mehta', specialty: 'Labour & Employment', exp: '12 years', rating: 4.9, reviews: 247, location: 'Pune', available: true, fee: '₹500/30 min' },
  { id: 2, name: 'Adv. Rahul Sharma', specialty: 'Criminal Defence', exp: '8 years', rating: 4.7, reviews: 189, location: 'Mumbai', available: true, fee: '₹800/30 min' },
  { id: 3, name: 'Adv. Sunita Rao', specialty: 'Family & Divorce', exp: '15 years', rating: 4.8, reviews: 312, location: 'Bengaluru', available: false, fee: '₹600/30 min' },
  { id: 4, name: 'Adv. Amir Khan', specialty: 'Property & Land', exp: '10 years', rating: 4.6, reviews: 143, location: 'Delhi', available: true, fee: '₹700/30 min' },
];

const mockConvo = [
  { id: 1, role: 'lawyer', content: 'Hello! I\'m Adv. Priya Mehta, specialising in Labour & Employment law. How can I help you today?', time: '10:00 AM' },
  { id: 2, role: 'user', content: 'My employer hasn\'t paid me for 2 months. I work at a garment factory.', time: '10:02 AM' },
  { id: 3, role: 'lawyer', content: 'This is a clear violation under the **Payment of Wages Act, 1936**. You have strong grounds. The first step is to file a complaint with the Labour Inspector for your area — this is completely free. Can you tell me which district you\'re in so I can guide you to the right office?', time: '10:03 AM' },
];

export default function ChatLawyer() {
  const [selected, setSelected] = useState(null);
  const [messages, setMessages] = useState(mockConvo);
  const [input, setInput] = useState('');

  const send = () => {
    if (!input.trim()) return;
    setMessages(m => [...m,
      { id: Date.now(), role: 'user', content: input, time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) },
    ]);
    setInput('');
    setTimeout(() => {
      setMessages(m => [...m, {
        id: Date.now() + 1,
        role: 'lawyer',
        content: 'Thank you for sharing that. Based on what you\'ve told me, I\'d recommend gathering all your pay slips, appointment letter, and any written communication with your employer. This will be critical evidence. Would you like me to explain what to say at the Labour Inspector\'s office?',
        time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      }]);
    }, 1200);
  };

  if (selected) {
    return (
      <AppLayout>
        <div className={styles.chatPage}>
          <div className={styles.chatTopBar}>
            <button className={styles.backBtn} onClick={() => setSelected(null)}>← Back to Lawyers</button>
            <div className={styles.lawyerMini}>
              <div className={styles.lawyerAvatar}>{selected.name.charAt(5)}</div>
              <div>
                <div className={styles.lawyerMiniName}>{selected.name}</div>
                <div className={styles.lawyerMiniSpec}>{selected.specialty}</div>
              </div>
            </div>
            <Badge variant="success" dot>Online</Badge>
          </div>

          <div className={styles.chatWindow}>
            {messages.map(msg => (
              <div key={msg.id} className={`${styles.msgRow} ${msg.role === 'user' ? styles.userRow : styles.lawyerRow}`}>
                {msg.role === 'lawyer' && (
                  <div className={styles.lawyerDot}>{selected.name.charAt(5)}</div>
                )}
                <div className={styles.msgWrap}>
                  <div className={`${styles.bubble} ${msg.role === 'user' ? styles.userBubble : styles.lawyerBubble}`}>
                    <span dangerouslySetInnerHTML={{ __html: msg.content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                  </div>
                  <span className={styles.msgTime}>{msg.time}</span>
                </div>
              </div>
            ))}
          </div>

          <div className={styles.inputRow}>
            <input
              className={styles.chatInput}
              placeholder="Type your message..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && send()}
            />
            <button className={`${styles.sendBtn} ${input.trim() ? styles.sendActive : ''}`} onClick={send}>
              <Send size={16} />
            </button>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <h1 className={styles.pageTitle}>Chat with a Lawyer</h1>
          <p className={styles.pageSub}>Connect with verified Indian lawyers for paid consultations</p>
        </div>

        <div className={styles.lawyerGrid}>
          {lawyers.map(l => (
            <Card key={l.id} hover className={styles.lawyerCard}>
              <div className={styles.lawyerTop}>
                <div className={styles.lawyerAvatar2}>{l.name.charAt(5)}</div>
                <Badge variant={l.available ? 'success' : 'default'} dot size="sm">
                  {l.available ? 'Available' : 'Busy'}
                </Badge>
              </div>
              <h3 className={styles.lawyerName}>{l.name}</h3>
              <div className={styles.lawyerSpec}>
                <Scale size={12} />
                {l.specialty}
              </div>
              <div className={styles.lawyerMeta}>
                <span className={styles.metaItem}><CheckCircle size={11} />{l.exp} exp.</span>
                <span className={styles.metaItem}><MapPin size={11} />{l.location}</span>
              </div>
              <div className={styles.lawyerRating}>
                <Star size={13} fill="var(--accent)" color="var(--accent)" />
                <span className={styles.ratingVal}>{l.rating}</span>
                <span className={styles.ratingCount}>({l.reviews} reviews)</span>
              </div>
              <div className={styles.lawyerFee}>{l.fee}</div>
              <Button
                full
                variant={l.available ? 'primary' : 'secondary'}
                disabled={!l.available}
                onClick={() => setSelected(l)}
              >
                {l.available ? 'Start Chat' : 'Not Available'}
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
