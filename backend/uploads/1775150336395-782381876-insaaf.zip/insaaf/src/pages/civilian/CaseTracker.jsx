import { useState } from 'react';
import { Plus, Calendar, Clock, FileText, ChevronRight, Search } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import RiskScore from '../../components/ui/RiskScore';
import Modal from '../../components/ui/Modal';
import Timeline from '../../components/ui/Timeline';
import Input from '../../components/ui/Input';
import SearchBar from '../../components/ui/SearchBar';
import Tabs from '../../components/ui/Tabs';
import { mockCases } from '../../data/mockData';
import styles from './CaseTracker.module.css';

const statusVariant = { active: 'success', pending: 'warning', closed: 'default' };

const caseTimeline = [
  { id: 1, type: 'success', icon: '✓', title: 'Case Filed', description: 'FIR lodged at Pune Police Station. Case registered under Payment of Wages Act.', date: '12 Jan 2025', tags: ['FIR', 'Police Station'] },
  { id: 2, type: 'info', icon: '📋', title: 'First Hearing', description: 'Notice served to employer. Court directed employer to file reply within 30 days.', date: '28 Jan 2025', tags: ['Court', 'Notice'] },
  { id: 3, type: 'warning', icon: '⏳', title: 'Employer Reply', description: 'Employer filed reply denying allegations. Counter-affidavit submitted.', date: '18 Feb 2025', tags: ['Affidavit'] },
  { id: 4, type: 'accent', icon: '📅', title: 'Next Hearing', description: 'Arguments to be heard. Prepare wage slips and attendance records.', date: '18 Apr 2025', tags: ['Upcoming', 'Documents Needed'] },
];

export default function CaseTracker() {
  const [tab, setTab] = useState('all');
  const [selectedCase, setSelectedCase] = useState(null);
  const [addModal, setAddModal] = useState(false);
  const [query, setQuery] = useState('');

  const filtered = mockCases.filter(c => {
    const matchesTab = tab === 'all' || c.status === tab;
    const matchesQuery = !query || c.title.toLowerCase().includes(query.toLowerCase());
    return matchesTab && matchesQuery;
  });

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <div>
            <h1 className={styles.pageTitle}>Case Tracker</h1>
            <p className={styles.pageSub}>Track all your active and past legal matters</p>
          </div>
          <Button icon={<Plus size={16} />} onClick={() => setAddModal(true)}>Add Case</Button>
        </div>

        <div className={styles.controls}>
          <Tabs
            tabs={[
              { id: 'all', label: 'All', count: mockCases.length },
              { id: 'active', label: 'Active', count: mockCases.filter(c => c.status === 'active').length },
              { id: 'pending', label: 'Pending', count: mockCases.filter(c => c.status === 'pending').length },
              { id: 'closed', label: 'Closed', count: mockCases.filter(c => c.status === 'closed').length },
            ]}
            onChange={setTab}
          />
          <SearchBar placeholder="Search cases..." value={query} onChange={setQuery} className={styles.searchBar} />
        </div>

        <div className={styles.caseGrid}>
          {filtered.map(c => (
            <Card key={c.id} hover className={styles.caseCard} onClick={() => setSelectedCase(c)}>
              <div className={styles.cardTop}>
                <div className={styles.caseInfo}>
                  <h3 className={styles.caseName}>{c.title}</h3>
                  <code className={styles.caseNo}>{c.caseNo}</code>
                </div>
                <RiskScore score={c.riskScore} size="md" />
              </div>

              <p className={styles.caseDesc}>{c.description}</p>

              <div className={styles.sections}>
                {c.sections.slice(0, 2).map(s => (
                  <span key={s} className={styles.section}>{s}</span>
                ))}
              </div>

              <div className={styles.cardMeta}>
                <Badge variant={statusVariant[c.status]}>{c.status}</Badge>
                <span className={styles.metaItem}>
                  <FileText size={12} />{c.type}
                </span>
                {c.nextHearing && (
                  <span className={styles.metaItem}>
                    <Calendar size={12} />
                    Next: {new Date(c.nextHearing).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                  </span>
                )}
                <span className={styles.metaItem}>
                  <Clock size={12} />
                  {new Date(c.lastUpdate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                </span>
              </div>

              <div className={styles.viewMore}>
                View Timeline <ChevronRight size={14} />
              </div>
            </Card>
          ))}

          {filtered.length === 0 && (
            <div className={styles.empty}>
              <Search size={32} />
              <p>No cases found</p>
            </div>
          )}
        </div>

        {/* Case Detail Modal */}
        <Modal
          isOpen={!!selectedCase}
          onClose={() => setSelectedCase(null)}
          title={selectedCase?.title}
          size="lg"
        >
          {selectedCase && (
            <div className={styles.modalContent}>
              <div className={styles.modalTop}>
                <div>
                  <code className={styles.caseNo}>{selectedCase.caseNo}</code>
                  <p className={styles.caseDesc2}>{selectedCase.description}</p>
                  <div className={styles.modalMeta}>
                    <Badge variant={statusVariant[selectedCase.status]}>{selectedCase.status}</Badge>
                    <Badge variant="default">{selectedCase.type}</Badge>
                  </div>
                </div>
                <RiskScore score={selectedCase.riskScore} size="lg" />
              </div>

              <div className={styles.divider} />

              <h3 className={styles.timelineHeading}>Case Timeline</h3>
              <Timeline events={caseTimeline} />
            </div>
          )}
        </Modal>

        {/* Add Case Modal */}
        <Modal
          isOpen={addModal}
          onClose={() => setAddModal(false)}
          title="Add New Case"
          size="md"
          footer={
            <>
              <Button variant="secondary" onClick={() => setAddModal(false)}>Cancel</Button>
              <Button onClick={() => setAddModal(false)}>Add Case</Button>
            </>
          }
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Input label="Case Title" placeholder="Brief description of the matter" />
            <Input label="Case / CNR Number" placeholder="e.g. CNR-MH-2025-XXXXXX" />
            <Input label="Court Name" placeholder="e.g. Labour Court, Pune" />
            <Input label="Next Hearing Date" type="date" />
          </div>
        </Modal>
      </div>
    </AppLayout>
  );
}
