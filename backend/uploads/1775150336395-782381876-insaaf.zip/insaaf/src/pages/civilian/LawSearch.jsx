import { useState } from 'react';
import { BookOpen, Search, Tag, Scale, ChevronRight, CheckCircle, ArrowLeft, Sparkles } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import SearchBar from '../../components/ui/SearchBar';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import Tabs from '../../components/ui/Tabs';
import ELI15Toggle from '../../components/ui/ELI15Toggle';
import { mockLaws, mockMCQFlow, mcqResult } from '../../data/mockData';
import styles from './LawSearch.module.css';

const severityVariant = { high: 'danger', medium: 'warning', low: 'info' };
const categoryVariant = { Criminal: 'danger', Constitutional: 'info', 'Special Law': 'warning', Civil: 'success' };

export default function LawSearch() {
  const [tab, setTab] = useState('browse');
  const [query, setQuery] = useState('');
  const [mcqStep, setMcqStep] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [mcqDone, setMcqDone] = useState(false);
  const [eli15, setEli15] = useState(false);

  const filtered = mockLaws.filter(l =>
    !query || l.title.toLowerCase().includes(query.toLowerCase()) ||
    l.code.toLowerCase().includes(query.toLowerCase()) ||
    l.tags.some(t => t.includes(query.toLowerCase()))
  );

  const handleMcqAnswer = (answer) => {
    const newAnswers = [...answers, answer];
    setAnswers(newAnswers);
    if (mcqStep < mockMCQFlow.length - 1) {
      setMcqStep(s => s + 1);
    } else {
      setMcqDone(true);
    }
  };

  const resetMcq = () => { setMcqStep(0); setAnswers([]); setMcqDone(false); };

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <div>
            <h1 className={styles.pageTitle}>Law Search</h1>
            <p className={styles.pageSub}>Search IPC / BNS / Constitution / Special Laws</p>
          </div>
          <ELI15Toggle onToggle={setEli15} />
        </div>

        <Tabs
          tabs={[
            { id: 'browse', label: 'Browse Laws', icon: <BookOpen size={14} /> },
            { id: 'mcq', label: 'Who is Liable?', icon: <Scale size={14} /> },
          ]}
          defaultTab="browse"
          onChange={setTab}
        />

        {tab === 'browse' && (
          <div className={styles.browseSection}>
            <SearchBar
              placeholder="Search by section, keyword, or topic..."
              value={query}
              onChange={setQuery}
              className={styles.searchBar}
            />
            {eli15 && (
              <div className={styles.eli15Banner}>
                <Sparkles size={14} />
                <span>ELI15 mode on — explanations are simplified to plain language</span>
              </div>
            )}
            <div className={styles.lawGrid}>
              {filtered.map(law => (
                <Card key={law.id} hover className={styles.lawCard}>
                  <div className={styles.lawHeader}>
                    <span className={styles.lawCode}>{law.code}</span>
                    <Badge variant={categoryVariant[law.category] || 'default'} size="sm">{law.category}</Badge>
                  </div>
                  <h3 className={styles.lawTitle}>{law.title}</h3>
                  <p className={styles.lawDesc}>
                    {eli15
                      ? `In simple terms: ${law.description.substring(0, 80)}...`
                      : law.description
                    }
                  </p>
                  <div className={styles.lawMeta}>
                    <div className={styles.punishment}>
                      <span className={styles.punishLabel}>Punishment</span>
                      <span className={styles.punishValue}>{law.punishment}</span>
                    </div>
                    {law.replaces && (
                      <Badge variant="default" size="sm">Replaces {law.replaces}</Badge>
                    )}
                  </div>
                  <div className={styles.tags}>
                    {law.tags.map(t => (
                      <span key={t} className={styles.tag}>
                        <Tag size={10} />{t}
                      </span>
                    ))}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {tab === 'mcq' && (
          <div className={styles.mcqSection}>
            {!mcqDone ? (
              <Card padding="lg" className={styles.mcqCard}>
                <div className={styles.mcqProgress}>
                  <span className={styles.mcqStep}>Question {mcqStep + 1} of {mockMCQFlow.length}</span>
                  <div className={styles.progressBar}>
                    <div
                      className={styles.progressFill}
                      style={{ width: `${((mcqStep) / mockMCQFlow.length) * 100}%` }}
                    />
                  </div>
                </div>

                <h2 className={styles.mcqQuestion}>{mockMCQFlow[mcqStep].question}</h2>
                <p className={styles.mcqHint}>Select the option that best matches your situation</p>

                <div className={styles.mcqOptions}>
                  {mockMCQFlow[mcqStep].options.map((opt, i) => (
                    <button key={i} className={styles.mcqOption} onClick={() => handleMcqAnswer(opt)}>
                      <span className={styles.optionText}>{opt}</span>
                      <ChevronRight size={16} className={styles.optionArrow} />
                    </button>
                  ))}
                </div>

                {mcqStep > 0 && (
                  <button className={styles.backBtn} onClick={() => { setMcqStep(s => s - 1); setAnswers(a => a.slice(0, -1)); }}>
                    <ArrowLeft size={14} /> Back
                  </button>
                )}
              </Card>
            ) : (
              <div className={styles.mcqResult}>
                <Card padding="lg" className={styles.resultHeader}>
                  <div className={styles.resultIcon}>
                    <CheckCircle size={32} />
                  </div>
                  <h2 className={styles.resultTitle}>Analysis Complete</h2>
                  <p className={styles.resultSummary}>{mcqResult.summary}</p>
                </Card>

                <div className={styles.sectionsList}>
                  <h3 className={styles.sectionsTitle}>Applicable Laws & Sections</h3>
                  {mcqResult.sections.map((s, i) => (
                    <Card key={i} className={styles.sectionCard}>
                      <div className={styles.sectionHeader2}>
                        <span className={styles.sectionCode}>{s.code}</span>
                        <Badge variant={severityVariant[s.severity]} size="sm">{s.severity} risk</Badge>
                      </div>
                      <p className={styles.sectionDesc}>{s.description}</p>
                    </Card>
                  ))}
                </div>

                <Card className={styles.recommendCard} padding="lg">
                  <h3 className={styles.recTitle}>💡 Recommendation</h3>
                  <p className={styles.recText}>{mcqResult.recommendation}</p>
                  <div style={{ display: 'flex', gap: 12, marginTop: 16, flexWrap: 'wrap' }}>
                    <Button variant="primary" onClick={() => {}}>Chat with AI Assistant</Button>
                    <Button variant="secondary" onClick={resetMcq}>Start Over</Button>
                  </div>
                </Card>
              </div>
            )}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
