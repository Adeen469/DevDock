import { useState } from 'react';
import { Plus, Pin, Search, Tag, Trash2, BookMarked } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import SearchBar from '../../components/ui/SearchBar';
import Modal from '../../components/ui/Modal';
import Input, { Textarea } from '../../components/ui/Input';
import { mockMemories } from '../../data/mockData';
import styles from './MemoryBank.module.css';

export default function MemoryBank() {
  const [memories, setMemories] = useState(mockMemories);
  const [query, setQuery] = useState('');
  const [addModal, setAddModal] = useState(false);
  const [newMem, setNewMem] = useState({ title: '', content: '', tags: '' });

  const filtered = memories.filter(m =>
    !query || m.title.toLowerCase().includes(query.toLowerCase()) ||
    m.content.toLowerCase().includes(query.toLowerCase()) ||
    m.tags.some(t => t.includes(query.toLowerCase()))
  );

  const pinned = filtered.filter(m => m.pinned);
  const unpinned = filtered.filter(m => !m.pinned);

  const togglePin = (id) => setMemories(ms => ms.map(m => m.id === id ? { ...m, pinned: !m.pinned } : m));
  const remove = (id) => setMemories(ms => ms.filter(m => m.id !== id));

  const save = () => {
    const mem = {
      id: Date.now(),
      title: newMem.title,
      content: newMem.content,
      tags: newMem.tags.split(',').map(t => t.trim()).filter(Boolean),
      saved: new Date().toISOString().split('T')[0],
      pinned: false,
    };
    setMemories(ms => [mem, ...ms]);
    setAddModal(false);
    setNewMem({ title: '', content: '', tags: '' });
  };

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.pageHeader}>
          <div>
            <h1 className={styles.pageTitle}>Memory Bank</h1>
            <p className={styles.pageSub}>Save important laws, rights, and legal notes for quick access</p>
          </div>
          <Button icon={<Plus size={16} />} onClick={() => setAddModal(true)}>Save Note</Button>
        </div>

        <SearchBar placeholder="Search your saved notes..." value={query} onChange={setQuery} />

        {pinned.length > 0 && (
          <div className={styles.section}>
            <div className={styles.sectionLabel}>
              <Pin size={13} /> Pinned
            </div>
            <div className={styles.grid}>
              {pinned.map(m => <MemoryCard key={m.id} memory={m} onPin={() => togglePin(m.id)} onDelete={() => remove(m.id)} />)}
            </div>
          </div>
        )}

        <div className={styles.section}>
          {pinned.length > 0 && (
            <div className={styles.sectionLabel}>
              <BookMarked size={13} /> All Notes
            </div>
          )}
          <div className={styles.grid}>
            {unpinned.map(m => <MemoryCard key={m.id} memory={m} onPin={() => togglePin(m.id)} onDelete={() => remove(m.id)} />)}
          </div>
          {filtered.length === 0 && (
            <div className={styles.empty}>
              <BookMarked size={32} />
              <p>No saved notes yet</p>
              <span>Save important laws and legal information for quick access</span>
            </div>
          )}
        </div>

        <Modal
          isOpen={addModal}
          onClose={() => setAddModal(false)}
          title="Save to Memory Bank"
          footer={
            <>
              <Button variant="secondary" onClick={() => setAddModal(false)}>Cancel</Button>
              <Button onClick={save} disabled={!newMem.title || !newMem.content}>Save Note</Button>
            </>
          }
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Input label="Title" placeholder="e.g. Rights during police questioning" value={newMem.title} onChange={e => setNewMem(n => ({ ...n, title: e.target.value }))} />
            <Textarea label="Note content" placeholder="What do you want to remember?" value={newMem.content} onChange={e => setNewMem(n => ({ ...n, content: e.target.value }))} />
            <Input label="Tags (comma separated)" placeholder="e.g. police, rights, FIR" icon={<Tag size={16} />} value={newMem.tags} onChange={e => setNewMem(n => ({ ...n, tags: e.target.value }))} hint="Helps you find notes later" />
          </div>
        </Modal>
      </div>
    </AppLayout>
  );
}

function MemoryCard({ memory, onPin, onDelete }) {
  return (
    <Card hover className={styles.memCard}>
      <div className={styles.memHeader}>
        <h3 className={styles.memTitle}>{memory.title}</h3>
        <div className={styles.memActions}>
          <button className={`${styles.memBtn} ${memory.pinned ? styles.pinned : ''}`} onClick={onPin} title={memory.pinned ? 'Unpin' : 'Pin'}>
            <Pin size={14} />
          </button>
          <button className={`${styles.memBtn} ${styles.deleteBtn}`} onClick={onDelete} title="Delete">
            <Trash2 size={14} />
          </button>
        </div>
      </div>
      <p className={styles.memContent}>{memory.content}</p>
      <div className={styles.memFooter}>
        <div className={styles.memTags}>
          {memory.tags.map(t => (
            <span key={t} className={styles.memTag}>
              <Tag size={10} />{t}
            </span>
          ))}
        </div>
        <span className={styles.memDate}>{new Date(memory.saved).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
      </div>
    </Card>
  );
}
