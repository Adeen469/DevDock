import { useState, useRef, useEffect } from 'react';
import { Send, Mic, Bot, User as UserIcon, Sparkles, RotateCcw } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import ELI15Toggle from '../../components/ui/ELI15Toggle';
import { mockChatMessages } from '../../data/mockData';
import styles from './Assistant.module.css';

function parseMarkdown(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br/>')
    .replace(/^\d+\.\s(.+)/gm, '<li>$1</li>');
}

export default function Assistant() {
  const [messages, setMessages] = useState(mockChatMessages);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [eli15, setEli15] = useState(false);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = { id: Date.now(), role: 'user', content: input, time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) };
    setMessages(m => [...m, userMsg]);
    setInput('');
    setLoading(true);

    await new Promise(r => setTimeout(r, 1200));

    const aiResponses = [
      "I understand your concern. Under Indian law, you have several options available. The key legislation that applies here is the **Payment of Wages Act, 1936** and **BNS Section 316**.\n\n**Steps to take:**\n1. Document all evidence — receipts, messages, bank statements\n2. File a complaint with the Labour Inspector (free)\n3. Send a legal notice through a lawyer\n\nWould you like detailed guidance on any of these steps?",
      "That's an important question. Based on the situation you've described, there are **multiple legal remedies** available under Indian law.\n\nThe most relevant sections are:\n- **Article 21** — Right to life and liberty\n- **BNS § 115** — Voluntary causing hurt\n\nI recommend consulting with a lawyer before proceeding.",
      eli15
        ? "In simple words: Yes, this can be illegal. The police must follow rules when they stop you. If they don't, you can complain about it later in court. You don't have to say things that can get you in trouble."
        : "Under Article 20(3) of the Constitution, you have the **right against self-incrimination**. You cannot be compelled to be a witness against yourself.\n\nThe police must follow the **CrPC/BNSS** procedures strictly. Any violation can be challenged in the High Court through a Writ Petition.",
    ];

    const aiMsg = {
      id: Date.now() + 1,
      role: 'assistant',
      content: aiResponses[Math.floor(Math.random() * aiResponses.length)],
      time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages(m => [...m, aiMsg]);
    setLoading(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
  };

  const quickPrompts = [
    'What are my rights if I\'m arrested?',
    'How to file an FIR?',
    'What is Section 498A?',
    'Can police enter my house without warrant?',
  ];

  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.chatHeader}>
          <div className={styles.botInfo}>
            <div className={styles.botAvatar}>
              <Bot size={18} />
            </div>
            <div>
              <div className={styles.botName}>Insaaf AI Assistant</div>
              <div className={styles.botStatus}><span className={styles.onlineDot} />Online — Powered by GPT-4o</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <ELI15Toggle onToggle={setEli15} />
            <button className={styles.resetBtn} onClick={() => setMessages(mockChatMessages.slice(0, 1))} title="Clear chat">
              <RotateCcw size={16} />
            </button>
          </div>
        </div>

        <div className={styles.chatWindow}>
          <div className={styles.disclaimer}>
            <Sparkles size={12} />
            Insaaf AI provides legal information only, not legal advice. For specific matters, always consult a qualified lawyer.
          </div>

          {messages.map((msg, i) => (
            <div key={msg.id} className={`${styles.messageRow} ${msg.role === 'user' ? styles.userRow : styles.aiRow}`} style={{ animationDelay: `${i * 0.05}s` }}>
              <div className={`${styles.avatar} ${msg.role === 'user' ? styles.userAvatar : styles.aiAvatar}`}>
                {msg.role === 'user' ? <UserIcon size={14} /> : <Bot size={14} />}
              </div>
              <div className={styles.messageWrap}>
                <div className={`${styles.bubble} ${msg.role === 'user' ? styles.userBubble : styles.aiBubble}`}>
                  <div
                    className={styles.msgContent}
                    dangerouslySetInnerHTML={{ __html: parseMarkdown(msg.content) }}
                  />
                </div>
                <span className={styles.time}>{msg.time}</span>
              </div>
            </div>
          ))}

          {loading && (
            <div className={`${styles.messageRow} ${styles.aiRow}`}>
              <div className={`${styles.avatar} ${styles.aiAvatar}`}><Bot size={14} /></div>
              <div className={styles.messageWrap}>
                <div className={`${styles.bubble} ${styles.aiBubble}`}>
                  <div className={styles.typing}>
                    <span /><span /><span />
                  </div>
                </div>
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {messages.length <= 2 && (
          <div className={styles.quickPrompts}>
            <p className={styles.quickLabel}>Try asking:</p>
            <div className={styles.promptGrid}>
              {quickPrompts.map(p => (
                <button key={p} className={styles.promptBtn} onClick={() => { setInput(p); inputRef.current?.focus(); }}>
                  {p}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className={styles.inputArea}>
          <textarea
            ref={inputRef}
            className={styles.textarea}
            placeholder="Ask about any law, your rights, or your legal situation..."
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            rows={1}
            style={{ height: 'auto' }}
            onInput={e => {
              e.target.style.height = 'auto';
              e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
            }}
          />
          <div className={styles.inputActions}>
            <button className={styles.micBtn} title="Voice input">
              <Mic size={18} />
            </button>
            <button
              className={`${styles.sendBtn} ${input.trim() ? styles.sendActive : ''}`}
              onClick={send}
              disabled={!input.trim() || loading}
            >
              <Send size={16} />
            </button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
