import { Phone, Shield, MapPin, AlertTriangle, FileText, MessageCircle } from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import styles from './Emergency.module.css';

const contacts = [
  { name: 'Police', number: '100', color: '#ef4444', icon: <Shield size={20} />, desc: 'Emergency police assistance' },
  { name: 'Women Helpline', number: '1091', color: '#8b5cf6', icon: <Phone size={20} />, desc: 'National women safety helpline' },
  { name: 'Child Helpline', number: '1098', color: '#3b82f6', icon: <Phone size={20} />, desc: 'Child abuse and emergency' },
  { name: 'Legal Aid', number: '15100', color: '#22c55e', icon: <FileText size={20} />, desc: 'Free legal aid services' },
  { name: 'Cyber Crime', number: '1930', color: '#f59e0b', icon: <Shield size={20} />, desc: 'Online fraud and cyber crime' },
  { name: 'Labour Helpline', number: '14567', color: '#c9a84c', icon: <Phone size={20} />, desc: 'Labour rights and wages' },
];

const rights = [
  { title: 'Right to Remain Silent', body: 'Under Article 20(3), you cannot be forced to testify against yourself. You may stay silent until a lawyer is present.', icon: '🤫' },
  { title: 'Right to a Lawyer', body: 'Under Article 22(1), you are entitled to consult a lawyer of your choice. Demand this immediately upon arrest.', icon: '⚖️' },
  { title: 'Right to Know the Reason', body: 'Police must inform you of the grounds for arrest at the time of arrest. You have a right to this information.', icon: '📋' },
  { title: 'Bail Rights', body: 'For bailable offences, you are entitled to bail. The police cannot deny bail for bailable offences.', icon: '🔓' },
  { title: 'Protection from Torture', body: 'Under Article 21, no torture or cruel treatment is permitted. Any such treatment is a fundamental rights violation.', icon: '🛡️' },
  { title: 'Medical Examination', body: 'If injured or assaulted, you have the right to immediate medical examination and treatment, free of charge.', icon: '🏥' },
];

export default function Emergency() {
  return (
    <AppLayout>
      <div className={styles.page}>
        <div className={styles.alertBanner}>
          <AlertTriangle size={20} />
          <div>
            <strong>Emergency Information</strong>
            <span>If you are in immediate danger, call 112 (all emergencies) immediately.</span>
          </div>
          <a href="tel:112">
            <Button variant="danger" size="sm">Call 112</Button>
          </a>
        </div>

        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Emergency Contacts</h2>
          <div className={styles.contactsGrid}>
            {contacts.map(c => (
              <a key={c.number} href={`tel:${c.number}`} className={styles.contactCard} style={{ '--c-color': c.color }}>
                <div className={styles.contactIcon} style={{ background: `${c.color}18`, color: c.color }}>
                  {c.icon}
                </div>
                <div className={styles.contactInfo}>
                  <span className={styles.contactName}>{c.name}</span>
                  <span className={styles.contactDesc}>{c.desc}</span>
                </div>
                <div className={styles.contactNumber} style={{ color: c.color }}>
                  <Phone size={14} />
                  {c.number}
                </div>
              </a>
            ))}
          </div>
        </div>

        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Know Your Rights — Right Now</h2>
          <p className={styles.sectionSub}>If you've been arrested or detained, these rights protect you:</p>
          <div className={styles.rightsGrid}>
            {rights.map(r => (
              <Card key={r.title} className={styles.rightCard}>
                <div className={styles.rightEmoji}>{r.icon}</div>
                <div className={styles.rightContent}>
                  <h3 className={styles.rightTitle}>{r.title}</h3>
                  <p className={styles.rightBody}>{r.body}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <div className={styles.section}>
          <Card className={styles.aiCard} padding="lg">
            <div className={styles.aiCardContent}>
              <div>
                <h3 className={styles.aiTitle}>Need Immediate Legal Guidance?</h3>
                <p className={styles.aiBody}>Describe your emergency situation and our AI will guide you through your immediate legal options and next steps.</p>
              </div>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                <Button icon={<MessageCircle size={16} />}>Ask AI Now</Button>
                <Button variant="secondary" icon={<MapPin size={16} />}>Find Nearby Police Station</Button>
              </div>
            </div>
          </Card>
        </div>

        <div className={styles.disclaimer}>
          <AlertTriangle size={14} />
          Insaaf provides general legal information. In a life-threatening emergency, always call 112 first.
        </div>
      </div>
    </AppLayout>
  );
}
