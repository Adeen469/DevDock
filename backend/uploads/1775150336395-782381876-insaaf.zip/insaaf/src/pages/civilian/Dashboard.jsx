import { useNavigate } from 'react-router-dom';
import {
  Search, MessageSquare, FolderOpen, BookMarked,
  AlertTriangle, MessagesSquare, Calendar, TrendingUp, Clock,
  ChevronRight, Sparkles
} from 'lucide-react';
import AppLayout from '../../components/layout/AppLayout';
import Card from '../../components/ui/Card';
import StatCard from '../../components/ui/StatCard';
import Badge from '../../components/ui/Badge';
import RiskScore from '../../components/ui/RiskScore';
import Button from '../../components/ui/Button';
import { mockCases, mockHearings } from '../../data/mockData';
import { useAuth } from '../../context/AuthContext';
import styles from './Dashboard.module.css';

const quickActions = [
  { icon: <Search size={20} />, label: 'Search Laws', to: '/law-search', color: '#3b82f6', bg: 'rgba(59,130,246,0.12)' },
  { icon: <MessageSquare size={20} />, label: 'AI Assistant', to: '/assistant', color: '#8b5cf6', bg: 'rgba(139,92,246,0.12)' },
  { icon: <FolderOpen size={20} />, label: 'My Cases', to: '/case-tracker', color: '#f59e0b', bg: 'rgba(245,158,11,0.12)' },
  { icon: <BookMarked size={20} />, label: 'Memory Bank', to: '/memory-bank', color: '#22c55e', bg: 'rgba(34,197,94,0.12)' },
  { icon: <AlertTriangle size={20} />, label: 'Emergency', to: '/emergency', color: '#ef4444', bg: 'rgba(239,68,68,0.12)' },
  { icon: <MessagesSquare size={20} />, label: 'Chat Lawyer', to: '/chat-lawyer', color: '#c9a84c', bg: 'rgba(201,168,76,0.12)' },
];

const statusVariant = { active: 'success', pending: 'warning', closed: 'default' };

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

export default function CivilianDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const activeCases = mockCases.filter(c => c.status === 'active').length;
  const upcoming = mockHearings.filter(h => h.status === 'upcoming');
  const firstName = user?.name?.split(' ')[0] || 'there';

  return (
    <AppLayout>
      <div className={styles.page}>

        {/* Greeting banner */}
        <div className={styles.greetingBanner}>
          <div className={styles.greetingLeft}>
            <h1 className={styles.greetingTitle}>
              {getGreeting()}, <span className={styles.accentName}>{firstName}</span> 🙏
            </h1>
            <p className={styles.greetingSub}>
              {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </p>
          </div>
          <div className={styles.greetingRight}>
            <Button
              icon={<Sparkles size={15} />}
              onClick={() => navigate('/assistant')}
              size="sm"
              variant="outline"
            >
              Ask AI
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className={styles.statsGrid}>
          <StatCard
            label="Active Cases"
            value={activeCases}
            sub="Currently open"
            icon={<FolderOpen size={16} />}
            accentColor="var(--accent)"
            trend="2 this month"
            trendUp
          />
          <StatCard
            label="Upcoming Hearings"
            value={upcoming.length}
            sub="Next 30 days"
            icon={<Calendar size={16} />}
            accentColor="#3b82f6"
          />
          <StatCard
            label="Saved Laws"
            value="12"
            sub="In memory bank"
            icon={<BookMarked size={16} />}
            accentColor="#8b5cf6"
            trend="+3 this week"
            trendUp
          />
          <StatCard
            label="AI Queries"
            value="47"
            sub="This month"
            icon={<TrendingUp size={16} />}
            accentColor="#22c55e"
          />
        </div>

        {/* Quick Actions */}
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Quick Access</h2>
          <div className={styles.actionsGrid}>
            {quickActions.map(a => (
              <button key={a.to} className={styles.actionCard} onClick={() => navigate(a.to)}>
                <div className={styles.actionIcon} style={{ background: a.bg, color: a.color }}>
                  {a.icon}
                </div>
                <span className={styles.actionLabel}>{a.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className={styles.twoCol}>
          {/* Active Cases */}
          <div className={styles.section}>
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>My Cases</h2>
              <button className={styles.seeAll} onClick={() => navigate('/case-tracker')}>
                See all <ChevronRight size={13} />
              </button>
            </div>
            <div className={styles.caseList}>
              {mockCases.map(c => (
                <Card key={c.id} hover onClick={() => navigate('/case-tracker')} className={styles.caseCard} padding="sm">
                  <div className={styles.caseTop}>
                    <div className={styles.caseInfo}>
                      <span className={styles.caseName}>{c.title}</span>
                      <code className={styles.caseNo}>{c.caseNo}</code>
                    </div>
                    <RiskScore score={c.riskScore} size="sm" />
                  </div>
                  <div className={styles.caseMeta}>
                    <Badge variant={statusVariant[c.status]} size="sm" dot>{c.status}</Badge>
                    <span className={styles.caseType}>{c.type}</span>
                    {c.nextHearing && (
                      <span className={styles.nextHearing}>
                        <Clock size={11} />
                        {new Date(c.nextHearing).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                      </span>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Upcoming Hearings */}
          <div className={styles.section}>
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Upcoming Hearings</h2>
            </div>
            {upcoming.length === 0 ? (
              <Card className={styles.emptyHearings} padding="lg">
                <Calendar size={28} />
                <p>No upcoming hearings</p>
              </Card>
            ) : (
              <div className={styles.hearingList}>
                {upcoming.map(h => (
                  <Card key={h.id} padding="sm" className={styles.hearingCard}>
                    <div className={styles.hearingDate}>
                      <span className={styles.hearingDay}>
                        {new Date(h.date).toLocaleDateString('en-IN', { day: 'numeric' })}
                      </span>
                      <span className={styles.hearingMonth}>
                        {new Date(h.date).toLocaleDateString('en-IN', { month: 'short' })}
                      </span>
                    </div>
                    <div className={styles.hearingInfo}>
                      <div className={styles.hearingTitle}>{h.caseTitle}</div>
                      <div className={styles.hearingMeta}>{h.time} · {h.court}</div>
                    </div>
                    <Badge variant="warning" size="sm">Soon</Badge>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* AI Banner */}
        <Card className={styles.aiBanner} padding="lg">
          <div className={styles.aiBannerContent}>
            <div className={styles.aiBannerLeft}>
              <div className={styles.aiBannerIcon}>⚡</div>
              <div>
                <h3 className={styles.aiBannerTitle}>Try the AI Assistant</h3>
                <p className={styles.aiBannerDesc}>
                  Describe your legal situation and get instant analysis of applicable laws, your rights, and recommended next steps — in plain language.
                </p>
              </div>
            </div>
            <Button onClick={() => navigate('/assistant')} icon={<MessageSquare size={15} />}>
              Start Chat
            </Button>
          </div>
        </Card>

      </div>
    </AppLayout>
  );
}
