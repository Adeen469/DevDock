import { useNavigate } from 'react-router-dom';
import { Scale, User, ArrowRight, Shield, Zap, BookOpen } from 'lucide-react';
import InsaafLogo from '../components/ui/InsaafLogo';
import ThemeToggle from '../components/ui/ThemeToggle';
import styles from './RoleSelection.module.css';

export default function RoleSelection() {
  const navigate = useNavigate();

  return (
    <div className={styles.page}>
      <div className={styles.topBar}>
        <InsaafLogo size={32} />
        <ThemeToggle />
      </div>

      <div className={styles.hero}>
        <div className={styles.badge}>
          <Zap size={12} />
          <span>AI-Powered Legal Intelligence</span>
        </div>
        <h1 className={styles.heading}>
          Justice, Simplified<br />
          <span className={styles.accent}>for Everyone</span>
        </h1>
        <p className={styles.sub}>
          India's first mobile-first legal platform. Understand your rights,
          track your cases, and access expert legal tools — in plain language.
        </p>
      </div>

      <div className={styles.cards}>
        <button className={styles.roleCard} onClick={() => navigate('/login?role=civilian')}>
          <div className={styles.cardHeader}>
            <div className={`${styles.iconWrap} ${styles.civilian}`}>
              <User size={28} />
            </div>
            <ArrowRight size={18} className={styles.arrow} />
          </div>
          <h2 className={styles.cardTitle}>I'm a Citizen</h2>
          <p className={styles.cardDesc}>
            Understand your legal rights, find applicable laws for your situation, track your cases, and connect with lawyers.
          </p>
          <div className={styles.features}>
            {['Law Search', 'AI Assistant', 'Case Tracker', 'Emergency Panel'].map(f => (
              <span key={f} className={styles.feature}>{f}</span>
            ))}
          </div>
        </button>

        <button className={styles.roleCard} onClick={() => navigate('/login?role=lawyer')}>
          <div className={styles.cardHeader}>
            <div className={`${styles.iconWrap} ${styles.lawyer}`}>
              <Scale size={28} />
            </div>
            <ArrowRight size={18} className={styles.arrow} />
          </div>
          <h2 className={styles.cardTitle}>I'm a Lawyer</h2>
          <p className={styles.cardDesc}>
            Manage cases, schedule hearings, store documents, and use AI to draft documents and recommend legal sections.
          </p>
          <div className={styles.features}>
            {['Case Management', 'AI Drafting', 'Section Finder', 'Analytics'].map(f => (
              <span key={f} className={styles.feature}>{f}</span>
            ))}
          </div>
        </button>
      </div>

      <div className={styles.trust}>
        {[
          { icon: <Shield size={14} />, text: 'Secure & Private' },
          { icon: <BookOpen size={14} />, text: 'BNS / IPC / CPC Updated' },
          { icon: <Zap size={14} />, text: 'AI-Powered Analysis' },
        ].map(item => (
          <div key={item.text} className={styles.trustItem}>
            {item.icon}
            <span>{item.text}</span>
          </div>
        ))}
      </div>

      <div className={styles.disclaimer}>
        Insaaf provides legal information, not legal advice. Always consult a qualified lawyer for specific legal matters.
      </div>
    </div>
  );
}
