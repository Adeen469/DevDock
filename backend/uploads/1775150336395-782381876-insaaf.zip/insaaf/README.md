# ⚖️ Insaaf — Mobile-First Legal Intelligence Web Application

> *"Every person in India, regardless of education or income, deserves to understand the law that governs them. Every lawyer deserves tools that respect their time."*

## Overview

**Insaaf** is a production-ready React 18 frontend for an AI-powered legal intelligence platform serving two user types:

- **Citizens** — Understand laws, track cases, use AI assistant, access emergency legal help
- **Lawyers** — Full case management workspace with AI drafting, analytics, and client chat

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install --legacy-peer-deps

# 2. Start development server
npm run dev

# 3. Open in browser
# → http://localhost:5173
```

> **Demo login:** Click "Continue with Demo Account" on the Login page — no credentials needed.

---

## 📁 Project Structure

```
src/
├── styles/
│   └── global.css              # Theme variables, typography, animations
├── context/
│   ├── ThemeContext.jsx         # Dark/light mode (default: dark)
│   └── AuthContext.jsx          # Auth state, role-based routing
├── data/
│   └── mockData.js             # All mock data (cases, laws, hearings, chats)
├── hooks/
│   └── usePageTitle.js         # Dynamic document title hook
├── components/
│   ├── ui/
│   │   ├── InsaafLogo.jsx       # Custom SVG scales-of-justice logo
│   │   ├── Button.jsx           # primary | secondary | ghost | outline | danger
│   │   ├── Card.jsx             # Hoverable surface card
│   │   ├── Input.jsx            # Input + Textarea with icon slots
│   │   ├── Badge.jsx            # Status pills
│   │   ├── Tabs.jsx             # Pill tab switcher
│   │   ├── Modal.jsx            # Animated overlay modal
│   │   ├── StatCard.jsx         # KPI card with trend indicator
│   │   ├── SearchBar.jsx        # Search input with clear
│   │   ├── ThemeToggle.jsx      # Dark/light animated toggle
│   │   ├── NotificationBell.jsx # Dropdown notification panel
│   │   ├── UploadDropzone.jsx   # Drag-and-drop file upload
│   │   ├── RiskScore.jsx        # SVG circular risk gauge
│   │   ├── ELI15Toggle.jsx      # "Explain Like I'm 15" mode toggle
│   │   ├── Timeline.jsx         # Vertical event timeline
│   │   └── Splash.jsx           # Loading splash screen
│   └── layout/
│       ├── Sidebar.jsx          # Responsive: overlay/collapsed/expanded
│       ├── Header.jsx           # Sticky header with toggle + notifications
│       └── AppLayout.jsx        # Full shell layout
└── pages/
    ├── RoleSelection.jsx        # Landing — Citizen vs Lawyer selection
    ├── Login.jsx                # Login with demo shortcut
    ├── Register.jsx             # Registration form
    ├── NotFound.jsx             # 404 page
    ├── civilian/
    │   ├── Dashboard.jsx        # Stats, quick actions, cases, hearings
    │   ├── LawSearch.jsx        # Law browser + MCQ "Who is Liable?" flow
    │   ├── Assistant.jsx        # Full AI chat interface with ELI15 toggle
    │   ├── CaseTracker.jsx      # Case grid + timeline + risk scores
    │   ├── MemoryBank.jsx       # Save/pin/search legal notes
    │   ├── Emergency.jsx        # Emergency contacts + rights panel
    │   └── ChatLawyer.jsx       # Browse lawyers + live chat
    └── lawyer/
        ├── LawyerDashboard.jsx  # Revenue stats, cases, hearings, AI tools
        ├── LawyerCases.jsx      # Sortable case table
        ├── LawyerHearings.jsx   # Hearing manager with date cards
        ├── LawyerDocuments.jsx  # Document vault + PDF preview
        ├── AISummarizer.jsx     # Upload/paste → AI summary
        ├── SectionRecommender.jsx # Situation text → ranked sections
        ├── DraftGenerator.jsx   # Legal notice/application generator
        ├── ClientChat.jsx       # Split-panel client messaging
        └── Analytics.jsx        # Recharts: bar, pie, line charts
```

---

## 🎨 Design System

### Theme

| Token | Dark | Light |
|-------|------|-------|
| `--bg` | `#000000` | `#ffffff` |
| `--surface` | `#0f0f0f` | `#f7f7f7` |
| `--text` | `#ffffff` | `#000000` |
| `--border` | `#1f1f1f` | `#e5e5e5` |
| `--accent` | `#c9a84c` (gold) | `#b8860b` |

### Typography
- **Display/Headings:** Syne (800, 700, 600)
- **Body/UI:** DM Sans (400, 500, 600)

### Breakpoints
| Name | Width |
|------|-------|
| mobile | 375px |
| tablet | 768px |
| desktop | 1024px |
| large | 1280px |

---

## 🔐 Routes

### Public
| Path | Component |
|------|-----------|
| `/` | Role Selection |
| `/login` | Login (role via `?role=civilian\|lawyer`) |
| `/register` | Register |

### Civilian (Protected)
| Path | Page |
|------|------|
| `/dashboard` | Civilian Dashboard |
| `/law-search` | Law Search + MCQ Flow |
| `/assistant` | AI Chat Assistant |
| `/case-tracker` | Case Tracker |
| `/memory-bank` | Memory Bank |
| `/emergency` | Emergency Panel |
| `/chat-lawyer` | Chat with Lawyer |

### Lawyer (Protected)
| Path | Page |
|------|------|
| `/lawyer/dashboard` | Lawyer Dashboard |
| `/lawyer/cases` | Case Management |
| `/lawyer/hearings` | Hearing Manager |
| `/lawyer/documents` | Document Vault |
| `/lawyer/ai-summarizer` | AI Summarizer |
| `/lawyer/section-recommender` | Section Recommender |
| `/lawyer/draft-generator` | Draft Generator |
| `/lawyer/client-chat` | Client Chat |
| `/lawyer/analytics` | Analytics Dashboard |

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | React 18 |
| Build Tool | Vite 5 |
| Routing | React Router v6 |
| Charts | Recharts |
| Icons | Lucide React |
| Styling | CSS Modules + CSS Variables |
| Fonts | Syne + DM Sans (Google Fonts) |
| State | React Context (Theme + Auth) |

---

## ✨ Key Features Implemented

- ✅ Role Selection screen (Civilian / Lawyer)
- ✅ Dark mode / Light mode with persistent toggle
- ✅ Responsive sidebar: hamburger (mobile) → collapsed (tablet) → expanded (desktop)
- ✅ AI Chat Interface with ELI15 toggle
- ✅ MCQ "Who is Liable?" criminal analysis flow
- ✅ Case Tracker with risk score gauge + evidence timeline
- ✅ Memory Bank with pin/save/search
- ✅ Emergency contacts panel + Know Your Rights
- ✅ Law Search with section browser and tags
- ✅ Lawyer Case Management table
- ✅ Hearing Manager with date cards
- ✅ Document Vault with drag-and-drop upload + PDF preview
- ✅ AI Case Summarizer (upload or paste)
- ✅ Section Recommender (ranked BNS/IPC results)
- ✅ Draft Generator (legal notices, bail applications)
- ✅ Client Chat (split panel, WhatsApp-style)
- ✅ Analytics Dashboard (bar + pie + line charts via Recharts)
- ✅ Notification bell with unread count
- ✅ Risk Score circular widget
- ✅ Protected routes by role
- ✅ 404 page

---

## 📝 Notes

- All data is **mock** — no backend required to run the UI
- The `?role=civilian` or `?role=lawyer` query param on `/login` and `/register` sets the account role
- "Continue with Demo Account" on Login bypasses all forms for quick UI exploration
- ELI15 toggle on AI pages switches to plain-language explanations
- All CSS uses CSS Modules for full scoping — zero global style conflicts

---

*Insaaf provides legal information, not legal advice. Always consult a qualified lawyer for specific legal matters.*
